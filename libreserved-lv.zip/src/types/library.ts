export type UserRole = 'student' | 'librarian';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  password?: string;
  studentNumber?: string;
  department?: string;
  avatar?: string;
}

export type ExportReportType = 'borrowers' | 'inventory' | 'both';

export type ReservationStatus = 
  | 'pending'
  | 'ready_for_pickup'
  | 'borrowed'
  | 'returned'
  | 'cancelled'
  | 'waitlisted';

export interface Book {
  id: string;
  callNumber: string;
  isbn: string;
  title: string;
  author: string;
  category: string;
  totalCopies: number;
  availableCopies: number;
  coverImage: string;
  description: string;
  publishedYear: number;
  shelfLocation: string;
}

export interface Reservation {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor: string;
  bookCover: string;
  callNumber: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  reservationDate: string; // e.g., 'Nov 1, 2026'
  pickupDeadline: string;  // e.g., 'Nov 3, 2026, 5:00 PM'
  dueDate: string;        // e.g., 'Nov 8, 2026, 5:00 PM'
  status: ReservationStatus;
  waitlistPosition?: number;
  notes?: string;
}

export interface LibraryNotification {
  id: string;
  studentEmail: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'due_date' | 'ready_pickup' | 'reserved' | 'waitlist' | 'info';
  reservationId?: string;
}

export type ActiveTab = 'overview' | 'catalog' | 'reservations' | 'notifications';
export type LibrarianTab = 'overview' | 'borrowers' | 'inventory' | 'add-book';

