import React from 'react';
import { useLibrary } from '../context/LibraryContext';
import { LogOut, BookOpen, Bell, ArrowRight, Bookmark, Layers, Users, PlusCircle } from 'lucide-react';

interface HeaderProps {
  onOpenAuth: (role?: 'student' | 'librarian') => void;
  studentTab?: 'find-books' | 'my-reservations' | 'overview' | 'notifications';
  setStudentTab?: (tab: 'find-books' | 'my-reservations' | 'overview' | 'notifications') => void;
  librarianTab?: 'overview' | 'borrowers' | 'inventory' | 'add-book';
  setLibrarianTab?: (tab: 'overview' | 'borrowers' | 'inventory' | 'add-book') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAuth,
  studentTab = 'find-books',
  setStudentTab,
  librarianTab = 'overview',
  setLibrarianTab,
}) => {
  const { currentUser, logout, activeView, setActiveView, notifications } = useLibrary();

  const unreadCount = notifications.filter(
    (n) => !n.read && (!currentUser || n.studentEmail === currentUser.email)
  ).length;

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-[0_1px_3px_rgba(0,0,0,0.03)]">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2 sm:gap-6">
        {/* Zone 1: Official Logo provided by user & libreservelv URL badge */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={() => setActiveView('home')}
            className="flex items-center gap-2 sm:gap-2.5 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#16325C] rounded-lg p-0.5"
            aria-label="libreservelv Homepage"
          >
            <img
              src="/assets/aistudio/850698335_2226256467988917_3141871878674636534_n_dcf2d853.jpg"
              alt="libreservelv"
              className="h-8 sm:h-9.5 w-auto object-contain transition-transform group-hover:scale-[1.02]"
              referrerPolicy="no-referrer"
            />
            <div className="border-l border-slate-200 pl-2 sm:pl-2.5 py-0.5 hidden md:block">
              <p className="text-[10px] font-bold tracking-wider text-slate-500 uppercase leading-none">
                {activeView === 'student'
                  ? 'STUDENT PORTAL'
                  : activeView === 'librarian'
                  ? 'LIBRARIAN PORTAL'
                  : 'LA VERDAD CHRISTIAN COLLEGE'}
              </p>
            </div>
          </button>

          {/* Exclusive Website URL Identifier Badge */}
          <div className="hidden lg:flex items-center gap-1.5 px-2 py-0.5 bg-slate-100/90 text-slate-600 rounded-md text-[10px] font-mono border border-slate-200" title="Exclusive Website URL">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span className="font-semibold text-[#16325C]">libreservelv</span>
          </div>
        </div>

        {/* Zone 2: Navigation Links — Minimalist, zero-scroll */}
        <nav aria-label="Main Navigation" className="flex items-center justify-center shrink-0">
          {/* Homepage: Exactly 3 essential visible navigation links */}
          {activeView === 'home' && (
            <div className="flex items-center gap-1 sm:gap-2">
              <a
                href="#catalog-preview"
                className="px-2.5 sm:px-3.5 py-1.5 text-slate-700 hover:text-[#16325C] transition-colors whitespace-nowrap text-xs sm:text-sm font-semibold rounded-lg hover:bg-slate-100"
              >
                Catalog
              </a>
              <a
                href="#how-it-works"
                className="px-2.5 sm:px-3.5 py-1.5 text-slate-700 hover:text-[#16325C] transition-colors whitespace-nowrap text-xs sm:text-sm font-semibold rounded-lg hover:bg-slate-100"
              >
                How It Works
              </a>
              <a
                href="#about-lvcc"
                className="px-2.5 sm:px-3.5 py-1.5 text-slate-700 hover:text-[#16325C] transition-colors whitespace-nowrap text-xs sm:text-sm font-semibold rounded-lg hover:bg-slate-100"
              >
                About
              </a>
            </div>
          )}

          {/* Student Portal Navigation in Header: Minimalist, zero-scroll */}
          {activeView === 'student' && setStudentTab && (
            <div className="flex items-center gap-0.5 sm:gap-1 p-0.5 sm:p-1 bg-slate-100/95 rounded-xl border border-slate-200/60" role="tablist">
              <button
                type="button"
                role="tab"
                aria-selected={studentTab === 'find-books'}
                onClick={() => setStudentTab('find-books')}
                className={`px-2 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  studentTab === 'find-books'
                    ? 'bg-white text-[#16325C] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Catalog
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={studentTab === 'my-reservations'}
                onClick={() => setStudentTab('my-reservations')}
                className={`px-2 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  studentTab === 'my-reservations'
                    ? 'bg-white text-[#16325C] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Reservations
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={studentTab === 'overview'}
                onClick={() => setStudentTab('overview')}
                className={`px-2 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  studentTab === 'overview'
                    ? 'bg-white text-[#16325C] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                5 Slots
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={studentTab === 'notifications'}
                onClick={() => setStudentTab('notifications')}
                className={`px-2 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap relative ${
                  studentTab === 'notifications'
                    ? 'bg-white text-[#16325C] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Alerts</span>
                {unreadCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 bg-[#D4A017] text-white text-[9px] font-bold rounded-full">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>
          )}

          {/* Librarian Portal Navigation in Header: Minimalist, zero-scroll */}
          {activeView === 'librarian' && setLibrarianTab && (
            <div className="flex items-center gap-0.5 sm:gap-1 p-0.5 sm:p-1 bg-slate-100/95 rounded-xl border border-slate-200/60" role="tablist">
              <button
                type="button"
                role="tab"
                aria-selected={librarianTab === 'overview'}
                onClick={() => setLibrarianTab('overview')}
                className={`px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  librarianTab === 'overview'
                    ? 'bg-[#16325C] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#16325C] hover:bg-white/70'
                }`}
              >
                Overview
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={librarianTab === 'borrowers'}
                onClick={() => setLibrarianTab('borrowers')}
                className={`px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  librarianTab === 'borrowers'
                    ? 'bg-[#16325C] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#16325C] hover:bg-white/70'
                }`}
              >
                Borrowers
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={librarianTab === 'inventory'}
                onClick={() => setLibrarianTab('inventory')}
                className={`px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  librarianTab === 'inventory'
                    ? 'bg-[#16325C] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#16325C] hover:bg-white/70'
                }`}
              >
                Inventory
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={librarianTab === 'add-book'}
                onClick={() => setLibrarianTab('add-book')}
                className={`px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  librarianTab === 'add-book'
                    ? 'bg-[#16325C] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#16325C] hover:bg-white/70'
                }`}
              >
                + Add Book
              </button>
            </div>
          )}
        </nav>

        {/* Zone 3: Primary Action / User Profile */}
        <div className="flex items-center gap-3 shrink-0">
          {currentUser ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:block text-right">
                <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                <p className="text-[11px] text-slate-500 font-mono">{currentUser.email}</p>
              </div>

              <button
                type="button"
                onClick={logout}
                className="flex items-center gap-1.5 py-2 px-3.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-all active:scale-95 shadow-sm"
              >
                <LogOut className="w-3.5 h-3.5 text-slate-500" />
                <span>Sign out</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onOpenAuth('student')}
                className="hidden sm:inline-flex items-center gap-1.5 py-2 px-3 text-xs font-semibold text-[#16325C] hover:bg-slate-100 rounded-lg transition-colors"
              >
                Student Sign In
              </button>

              <button
                type="button"
                onClick={() => onOpenAuth()}
                className="flex items-center gap-2 py-2 px-4.5 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-lg transition-all shadow-sm active:scale-95 whitespace-nowrap"
              >
                <span>Log In</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#D4A017]" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
