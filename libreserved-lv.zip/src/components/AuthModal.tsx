import React, { useState } from 'react';
import { useLibrary } from '../context/LibraryContext';
import { UserRole } from '../types/library';
import {
  X,
  GraduationCap,
  ShieldCheck,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Lock,
  Mail,
  User as UserIcon,
  Eye,
  EyeOff,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialRole?: UserRole;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialRole = 'student' }) => {
  const { login } = useLibrary();
  const [selectedRole, setSelectedRole] = useState<UserRole>(initialRole);
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  
  // Remember password support
  const [rememberPassword, setRememberPassword] = useState<boolean>(() => {
    const saved = localStorage.getItem('libreserved_remember_password_enabled');
    return saved !== null ? saved === 'true' : true;
  });

  const [email, setEmail] = useState<string>(() => {
    return localStorage.getItem('libreserved_last_email') || '';
  });

  const [password, setPassword] = useState<string>(() => {
    const lastEmail = localStorage.getItem('libreserved_last_email') || '';
    if (lastEmail) {
      try {
        const savedPasswords = JSON.parse(localStorage.getItem('libreserved_remembered_passwords') || '{}');
        return savedPasswords[lastEmail.toLowerCase()] || '';
      } catch (e) {
        console.error(e);
      }
    }
    return '';
  });

  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isPasswordAutofilled, setIsPasswordAutofilled] = useState<boolean>(() => {
    const lastEmail = localStorage.getItem('libreserved_last_email') || '';
    if (lastEmail) {
      try {
        const savedPasswords = JSON.parse(localStorage.getItem('libreserved_remembered_passwords') || '{}');
        return !!savedPasswords[lastEmail.toLowerCase()];
      } catch (e) {
        return false;
      }
    }
    return false;
  });
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Whenever email changes, check if we have a remembered password for that account
  const handleEmailChange = (newEmail: string) => {
    setEmail(newEmail);
    const trimmed = newEmail.trim().toLowerCase();
    try {
      const savedPasswords = JSON.parse(localStorage.getItem('libreserved_remembered_passwords') || '{}');
      if (savedPasswords[trimmed]) {
        setPassword(savedPasswords[trimmed]);
        setIsPasswordAutofilled(true);
      } else {
        setIsPasswordAutofilled(false);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setError('Please provide your email address.');
      return;
    }

    if (isSignUp && !name.trim()) {
      setError('Please provide your full name.');
      return;
    }

    if (isSignUp && confirmPassword && password !== confirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    const effectivePassword = password.trim() || 'password';

    const res = login(trimmedEmail, selectedRole, effectivePassword, name.trim() || undefined, isSignUp);
    if (res.success) {
      // Remember password and last login preferences
      try {
        const savedPasswords = JSON.parse(localStorage.getItem('libreserved_remembered_passwords') || '{}');
        const normalizedEmail = trimmedEmail.toLowerCase();
        const fullEmail = normalizedEmail.includes('@')
          ? normalizedEmail
          : selectedRole === 'student'
          ? `${normalizedEmail}@student.laverdad.edu.ph`
          : `${normalizedEmail}@laverdad.edu.ph`;

        if (rememberPassword) {
          savedPasswords[fullEmail] = effectivePassword;
          savedPasswords[normalizedEmail] = effectivePassword;
          localStorage.setItem('libreserved_remembered_passwords', JSON.stringify(savedPasswords));
          localStorage.setItem('libreserved_last_email', fullEmail);
          localStorage.setItem('libreserved_last_role', selectedRole);
          localStorage.setItem('libreserved_remember_password_enabled', 'true');
        } else {
          delete savedPasswords[fullEmail];
          delete savedPasswords[normalizedEmail];
          localStorage.setItem('libreserved_remembered_passwords', JSON.stringify(savedPasswords));
          localStorage.setItem('libreserved_remember_password_enabled', 'false');
        }
      } catch (err) {
        console.error('Failed to persist remembered password:', err);
      }

      setError(null);
      onClose();
    } else {
      setError(res.error || 'Authentication failed. Please verify your credentials.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header bar */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 bg-[#FAF9F5]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#16325C] flex items-center justify-center text-white">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M19 2H5c-1.1 0-2 .9-2 2v18l9-4 9 4V4c0-1.1-.9-2-2-2z" />
              </svg>
            </div>
            <div>
              <h2 className="text-base font-bold text-[#16325C]">
                {isSignUp ? 'Create LibReserved LV Account' : 'Sign in to LibReserved LV'}
              </h2>
              <p className="text-xs text-slate-500">La Verdad Christian College Library Portal</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Portal Switcher Tabs */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl mb-5">
            <button
              type="button"
              onClick={() => handleRoleSelect('student')}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold rounded-lg transition-all ${
                selectedRole === 'student'
                  ? 'bg-white text-[#16325C] shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-[#D4A017]" />
              <span>Log In as a Student</span>
            </button>
            <button
              type="button"
              onClick={() => handleRoleSelect('librarian')}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold rounded-lg transition-all ${
                selectedRole === 'librarian'
                  ? 'bg-white text-[#16325C] shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-[#16325C]" />
              <span>Log In as a Librarian</span>
            </button>
          </div>

          {/* Mode Switcher: Sign In vs Create Account */}
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
            <span className="text-xs font-medium text-slate-500">
              {isSignUp ? 'Already registered?' : 'First time using LibReserved LV?'}
            </span>
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError(null);
              }}
              className="text-xs font-bold text-[#16325C] hover:text-[#D4A017] transition-colors"
            >
              {isSignUp ? 'Switch to Sign In' : 'Create an Account'}
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Full Name for registration */}
            {isSignUp && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name *
                </label>
                <div className="relative flex items-center">
                  <UserIcon className="absolute left-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder={selectedRole === 'student' ? 'e.g. Esheeunice Angeles' : 'e.g. Maria Santo'}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  {selectedRole === 'student' ? 'Student Institutional Email' : 'Librarian Staff Email'} *
                </label>
                <span className="text-[11px] font-mono text-[#16325C] font-semibold">
                  {selectedRole === 'student' ? '@student.laverdad.edu.ph' : '@laverdad.edu.ph'}
                </span>
              </div>
              <div className="relative flex items-center">
                <Mail className="absolute left-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder={
                    selectedRole === 'student'
                      ? 'e.g. esheeunice.angeles@student.laverdad.edu.ph'
                      : 'e.g. maria.santo@laverdad.edu.ph'
                  }
                  value={email}
                  onChange={(e) => handleEmailChange(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#16325C] font-mono text-slate-900"
                />
              </div>

              {/* Quick Append Domain button */}
              <div className="flex items-center gap-1.5 mt-2">
                <span className="text-[11px] text-slate-500">Quick domain:</span>
                {selectedRole === 'student' ? (
                  <button
                    type="button"
                    onClick={() => {
                      const raw = email.trim();
                      const prefix = raw.includes('@') ? raw.split('@')[0] : raw;
                      handleEmailChange(`${prefix || 'student'}@student.laverdad.edu.ph`);
                    }}
                    className="text-[10px] font-bold text-[#16325C] bg-[#16325C]/10 hover:bg-[#16325C] hover:text-white px-2.5 py-1 rounded transition-all"
                  >
                    + @student.laverdad.edu.ph
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      const raw = email.trim();
                      const prefix = raw.includes('@') ? raw.split('@')[0] : raw;
                      handleEmailChange(`${prefix || 'librarian'}@laverdad.edu.ph`);
                    }}
                    className="text-[10px] font-bold text-[#16325C] bg-[#16325C]/10 hover:bg-[#16325C] hover:text-white px-2.5 py-1 rounded transition-all"
                  >
                    + @laverdad.edu.ph
                  </button>
                )}
              </div>

              <p className="mt-1.5 text-[11px] text-slate-500 leading-tight">
                {selectedRole === 'student'
                  ? 'Access your student portal using your @student.laverdad.edu.ph institutional account.'
                  : 'Librarian circulation portal requires an authorized @laverdad.edu.ph staff account.'}
              </p>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Password *
                </label>
                {isPasswordAutofilled && (
                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Remembered password loaded
                  </span>
                )}
              </div>
              <div className="relative flex items-center">
                <Lock className="absolute left-3 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setIsPasswordAutofilled(false);
                  }}
                  className="w-full pl-9 pr-10 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#16325C] text-slate-900"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 p-1 text-slate-400 hover:text-slate-600 focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Remember Password Checkbox */}
              <div className="flex items-center justify-between mt-2 pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberPassword}
                    onChange={(e) => setRememberPassword(e.target.checked)}
                    className="w-4 h-4 text-[#16325C] rounded border-slate-300 focus:ring-[#16325C] cursor-pointer"
                  />
                  <span className="text-xs text-slate-600 font-medium">Remember password on this device</span>
                </label>
                {password && (
                  <span className="text-[11px] text-slate-400">
                    Saved securely in browser
                  </span>
                )}
              </div>
            </div>

            {/* Confirm Password on Sign Up */}
            {isSignUp && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Confirm Password *
                </label>
                <div className="relative flex items-center">
                  <Lock className="absolute left-3 w-4 h-4 text-slate-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Re-type your password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#16325C] text-slate-900"
                  />
                </div>
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] active:scale-[0.99] transition-all shadow-sm"
              >
                <span>
                  {isSignUp
                    ? `Create ${selectedRole === 'student' ? 'Student' : 'Librarian'} Account`
                    : `Sign In to ${selectedRole === 'student' ? 'Student' : 'Librarian'} Portal`}
                </span>
                <ArrowRight className="w-4 h-4 text-[#D4A017]" />
              </button>
            </div>
          </form>

          {/* Access Policy Note */}
          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center gap-2 text-[11px] text-slate-500">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>All library book reservations and borrowing privileges are 100% free of charge for students.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
