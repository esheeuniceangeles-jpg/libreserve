import React from 'react';
import { Book } from '../types/library';
import { useLibrary } from '../context/LibraryContext';
import { X, BookOpen, MapPin, Calendar, CheckCircle2, Bookmark, Layers } from 'lucide-react';

interface BookDetailModalProps {
  book: Book | null;
  onClose: () => void;
  onOpenAuth?: (role?: 'student' | 'librarian') => void;
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({ book, onClose, onOpenAuth }) => {
  const { currentUser, reserveBook, reservations } = useLibrary();

  if (!book) return null;

  const isStudent = currentUser?.role === 'student';
  const userExistingReservation = reservations.find(
    (r) => r.bookId === book.id && r.studentEmail === currentUser?.email && ['pending', 'ready_for_pickup', 'borrowed', 'waitlisted'].includes(r.status)
  );

  const handleAction = () => {
    if (!currentUser) {
      onClose();
      if (onOpenAuth) onOpenAuth('student');
      return;
    }

    if (isStudent) {
      reserveBook(book.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#FAF9F5]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#16325C]" />
            <span className="text-xs font-mono text-slate-500 uppercase tracking-wider">
              {book.callNumber}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          <div className="flex flex-col sm:flex-row gap-6">
            {/* Book Cover */}
            <div className="w-full sm:w-44 shrink-0 aspect-[3/4] bg-slate-100 rounded-xl overflow-hidden shadow-md border border-slate-200">
              <img
                src={book.coverImage}
                alt={book.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Book Details */}
            <div className="flex-1 space-y-3">
              <div>
                <span className="text-[11px] font-semibold text-[#16325C] bg-[#16325C]/10 px-2.5 py-0.5 rounded">
                  {book.category}
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-2 leading-snug">
                  {book.title}
                </h2>
                <p className="text-sm font-medium text-slate-600 mt-1">
                  By {book.author}
                </p>
              </div>

              {/* Status and shelf location */}
              <div className="pt-2 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  <MapPin className="w-4 h-4 text-[#D4A017] shrink-0" />
                  <span>
                    Location: <strong>{book.shelfLocation}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-2 text-slate-700">
                  <BookOpen className="w-4 h-4 text-[#16325C] shrink-0" />
                  <span>
                    Availability: <strong>{book.availableCopies} of {book.totalCopies} copies</strong> in library
                  </span>
                </div>

                <div className="flex items-center gap-2 text-slate-700">
                  <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>
                    Published: <strong>{book.publishedYear}</strong> · ISBN: <strong className="font-mono">{book.isbn}</strong>
                  </span>
                </div>
              </div>

              {/* Availability Alert */}
              <div className="pt-2">
                {book.availableCopies > 0 ? (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>In Stock. Immediate pickup reservation available.</span>
                  </div>
                ) : (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-2 text-xs text-amber-800">
                    <Bookmark className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>All copies currently checked out. Join the waitlist to receive priority hold upon return.</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Synopsis */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Book Synopsis
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {book.description}
            </p>
          </div>

          {/* Student 5-slot policy reminder */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#16325C]" />
              <span>Standard LVCC free borrowing privileges: 5 concurrent reservation slots.</span>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-[#FAF9F5] flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            Close
          </button>

          {userExistingReservation ? (
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg">
                Status: {userExistingReservation.status.replace(/_/g, ' ')}
              </span>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleAction}
              className={`flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white rounded-xl shadow-sm transition-all ${
                book.availableCopies > 0
                  ? 'bg-[#16325C] hover:bg-[#1a3d6f]'
                  : 'bg-[#B8860B] hover:bg-[#a07408]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>
                {!currentUser
                  ? 'Sign in to Reserve'
                  : isStudent
                  ? book.availableCopies > 0
                    ? 'Reserve This Book'
                    : 'Join Book Waitlist'
                  : 'Librarian View (Catalog item)'}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
