import React, { useState, useRef } from 'react';
import { useLibrary } from '../context/LibraryContext';
import { Book, Reservation, ReservationStatus, ExportReportType } from '../types/library';
import {
  Search,
  FileDown,
  BookOpen,
  Clock,
  CheckCircle,
  Plus,
  Trash2,
  Edit2,
  Users,
  Layers,
  FileText,
  AlertCircle,
  X,
  Sparkles,
  ArrowRight,
  Upload,
  Image as ImageIcon,
} from 'lucide-react';

interface LibrarianPortalProps {
  currentTab: 'overview' | 'borrowers' | 'inventory' | 'add-book';
  setTab: (tab: 'overview' | 'borrowers' | 'inventory' | 'add-book') => void;
  onSelectBook: (book: Book) => void;
}

export const LibrarianPortal: React.FC<LibrarianPortalProps> = ({
  currentTab,
  setTab,
  onSelectBook,
}) => {
  const {
    books,
    reservations,
    updateReservationStatus,
    addBook,
    deleteBook,
    exportCirculationPDF,
  } = useLibrary();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  // PDF Export modal state
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [selectedExportType, setSelectedExportType] = useState<ExportReportType>('both');

  // New book form state
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newCallNumber, setNewCallNumber] = useState('');
  const [newIsbn, setNewIsbn] = useState('');
  const [newCategory, setNewCategory] = useState('Computer Science');
  const [newCopies, setNewCopies] = useState<number>(3);
  const [newShelf, setNewShelf] = useState('2nd Floor - Shelf 4B');
  const [newDescription, setNewDescription] = useState('');
  const [selectedCover, setSelectedCover] = useState('/src/assets/images/book_algorithms_cover_1793519863231.jpg');
  const [isCustomUploaded, setIsCustomUploaded] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError(null);

    // Max 5MB check
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image size exceeds 5MB limit. Please choose a smaller photo.');
      return;
    }

    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (JPEG, PNG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setSelectedCover(event.target.result);
        setIsCustomUploaded(true);
        setUploadedFileName(file.name);
      }
    };
    reader.onerror = () => {
      setUploadError('Failed to read image file. Please try another picture.');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveCustomCover = () => {
    setSelectedCover('/src/assets/images/book_algorithms_cover_1793519863231.jpg');
    setIsCustomUploaded(false);
    setUploadedFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Dashboard metrics matching Screenshot 526
  const totalReservations = reservations.length;
  const awaitingPickup = reservations.filter((r) => r.status === 'ready_for_pickup').length;
  const currentlyBorrowed = reservations.filter((r) => r.status === 'borrowed').length;
  const returnedCount = reservations.filter((r) => r.status === 'returned').length;

  // Unique active students
  const activeStudentsSet = new Set(
    reservations.filter((r) => ['pending', 'ready_for_pickup', 'borrowed'].includes(r.status)).map((r) => r.studentEmail)
  );
  const activeStudentsCount = activeStudentsSet.size;

  // Filter borrowers
  const filteredReservations = reservations.filter((r) => {
    const matchesStatus =
      selectedStatus === 'all' || r.status.toLowerCase() === selectedStatus.toLowerCase();
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesStatus;

    return (
      matchesStatus &&
      (r.studentName.toLowerCase().includes(query) ||
        r.studentEmail.toLowerCase().includes(query) ||
        r.bookTitle.toLowerCase().includes(query) ||
        r.callNumber.toLowerCase().includes(query) ||
        r.reservationDate.toLowerCase().includes(query) ||
        r.dueDate.toLowerCase().includes(query) ||
        r.status.toLowerCase().includes(query))
    );
  });

  const handleCreateBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newAuthor.trim()) return;

    addBook({
      title: newTitle.trim(),
      author: newAuthor.trim(),
      callNumber: newCallNumber.trim() || 'QA 76.73 .L52 2024',
      isbn: newIsbn.trim() || '978-0131234567',
      category: newCategory,
      totalCopies: Number(newCopies) || 1,
      availableCopies: Number(newCopies) || 1,
      shelfLocation: newShelf.trim() || 'General Stacks',
      description: newDescription.trim() || 'Reference collection item for LVCC students.',
      publishedYear: 2024,
      coverImage: selectedCover,
    });

    // Reset
    setNewTitle('');
    setNewAuthor('');
    setNewCallNumber('');
    setNewDescription('');
    setIsCustomUploaded(false);
    setUploadedFileName('');
    if (fileInputRef.current) fileInputRef.current.value = '';
    setFeedbackNotice('New book successfully added to LVCC Library catalog with picture!');
    setTimeout(() => setFeedbackNotice(null), 4000);
    setTab('inventory');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Toast Alert */}
      {feedbackNotice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-xs font-semibold text-emerald-800 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>{feedbackNotice}</span>
          </div>
          <button onClick={() => setFeedbackNotice(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Minimalist Top Control Bar — Zero scrolling required */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded bg-slate-100 text-[11px] font-mono font-bold text-[#16325C] border border-slate-200">
            libreservelv
          </span>
          <span className="text-slate-300">/</span>
          <span className="text-xs font-semibold text-slate-700 capitalize">
            {currentTab.replace('-', ' ')}
          </span>
        </div>

        {/* Minimalist Tabs: compact, zero horizontal scroll */}
        <div className="flex items-center gap-1 bg-slate-100/90 p-1 rounded-lg" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={currentTab === 'overview'}
            onClick={() => setTab('overview')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${
              currentTab === 'overview'
                ? 'bg-[#16325C] text-white shadow-2xs'
                : 'text-slate-600 hover:text-[#16325C]'
            }`}
          >
            Overview
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={currentTab === 'borrowers'}
            onClick={() => setTab('borrowers')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              currentTab === 'borrowers'
                ? 'bg-[#16325C] text-white shadow-2xs'
                : 'text-slate-600 hover:text-[#16325C]'
            }`}
          >
            Borrowers
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={currentTab === 'inventory'}
            onClick={() => setTab('inventory')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              currentTab === 'inventory'
                ? 'bg-[#16325C] text-white shadow-2xs'
                : 'text-slate-600 hover:text-[#16325C]'
            }`}
          >
            Inventory
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={currentTab === 'add-book'}
            onClick={() => setTab('add-book')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              currentTab === 'add-book'
                ? 'bg-[#16325C] text-white shadow-2xs'
                : 'text-slate-600 hover:text-[#16325C]'
            }`}
          >
            + Add Book
          </button>
        </div>
      </div>

      {/* PAGE 1: OVERVIEW & CIRCULATION DASHBOARD SEPARATE PAGE */}
      {currentTab === 'overview' && (
        <div className="space-y-6">
          {/* Upper Search Bar */}
          <div className="p-5 bg-white rounded-2xl border-2 border-[#16325C]/20 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4A017]">
                  Circulation & Borrower Lookup
                </span>
                <h2 className="text-base sm:text-lg font-bold text-[#16325C]">
                  Find students who have borrowed or reserved books
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                {reservations.length} total records · {activeStudentsCount} active students
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
              <div className="relative flex-1 flex items-center">
                <Search className="absolute left-3.5 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by student name (e.g. Esheeunice), email, or book title..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 text-sm bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C] text-slate-900 placeholder:text-slate-400 transition-all font-medium"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 p-1 text-slate-400 hover:text-slate-600 rounded-md"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => setTab('borrowers')}
                className="px-5 py-3 text-xs sm:text-sm font-bold text-white bg-[#16325C] hover:bg-[#1a3d6f] active:scale-95 rounded-xl transition-all shadow-sm whitespace-nowrap shrink-0"
              >
                Search Records
              </button>
            </div>
          </div>

          {/* Title and PDF button */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pt-1">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
                Circulation dashboard
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-slate-500">
                See who reserved or borrowed books and export the report as a PDF.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setTab('add-book')}
                className="flex items-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-[#16325C] bg-white border border-slate-300 hover:bg-slate-50 rounded-xl transition-all shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add Book</span>
              </button>

              <button
                type="button"
                onClick={() => setIsExportModalOpen(true)}
                className="flex items-center gap-2 py-2.5 px-4.5 text-xs font-semibold text-slate-900 bg-[#E5A827] hover:bg-[#d89c1f] rounded-xl transition-all shadow-sm active:scale-95"
              >
                <FileDown className="w-4 h-4 text-slate-900" />
                <span>Export report to PDF</span>
              </button>
            </div>
          </div>

          {/* 4 Stat Cards matching screenshot 526 */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div
              onClick={() => setTab('borrowers')}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/30 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-slate-500">Total reservations</p>
                <FileText className="w-4 h-4 text-[#D4A017] transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {totalReservations}
              </p>
            </div>

            <div
              onClick={() => {
                setSelectedStatus('ready_for_pickup');
                setTab('borrowers');
              }}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/30 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-slate-500">Awaiting pickup</p>
                <Clock className="w-4 h-4 text-amber-600 transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {awaitingPickup}
              </p>
            </div>

            <div
              onClick={() => {
                setSelectedStatus('borrowed');
                setTab('borrowers');
              }}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/30 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-slate-500">Currently borrowed</p>
                <BookOpen className="w-4 h-4 text-[#16325C] transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {currentlyBorrowed}
              </p>
            </div>

            <div
              onClick={() => {
                setSelectedStatus('returned');
                setTab('borrowers');
              }}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/30 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-slate-500">Returned</p>
                <CheckCircle className="w-4 h-4 text-emerald-600 transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {returnedCount}
              </p>
            </div>
          </div>

          {/* Quick Nav Cards to other pages */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div
              onClick={() => setTab('borrowers')}
              className="p-6 bg-white rounded-2xl border border-slate-200 hover:border-[#16325C]/40 shadow-xs hover:shadow-md transition-all cursor-pointer flex items-center justify-between group"
            >
              <div>
                <div className="flex items-center gap-2 mb-1 text-[#16325C]">
                  <Users className="w-4 h-4" />
                  <h3 className="text-sm font-bold">Manage Borrowers & Holds</h3>
                </div>
                <p className="text-xs text-slate-500">
                  View full circulation ledger, issue books, and process returns.
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-slate-400 group-hover:text-[#16325C] group-hover:translate-x-1 transition-all" />
            </div>

            <div
              onClick={() => setTab('inventory')}
              className="p-6 bg-white rounded-2xl border border-slate-200 hover:border-[#16325C]/40 shadow-xs hover:shadow-md transition-all cursor-pointer flex items-center justify-between group"
            >
              <div>
                <div className="flex items-center gap-2 mb-1 text-[#16325C]">
                  <BookOpen className="w-4 h-4" />
                  <h3 className="text-sm font-bold">Manage Book Inventory</h3>
                </div>
                <p className="text-xs text-slate-500">
                  Inspect availability counts across all shelves and add new volumes.
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-slate-400 group-hover:text-[#16325C] group-hover:translate-x-1 transition-all" />
            </div>
          </div>
        </div>
      )}

      {/* PAGE 2: BORROWERS & CIRCULATION SEPARATE PAGE */}
      {currentTab === 'borrowers' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
                Who Reserved and Borrowed
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-slate-500">
                Full circulation register with instant search and status controls.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setIsExportModalOpen(true)}
              className="flex items-center gap-2 py-2 px-4 text-xs font-semibold text-slate-900 bg-[#E5A827] hover:bg-[#d89c1f] rounded-xl self-start sm:self-auto transition-all shadow-sm"
            >
              <FileDown className="w-4 h-4" />
              <span>Export PDF Report</span>
            </button>
          </div>

          {/* Search and filter bar matching screenshot */}
          <div className="flex flex-col sm:flex-row gap-2 p-2 bg-white rounded-xl shadow-xs border border-slate-200">
            <div className="relative flex-1 flex items-center">
              <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search student, email, book, or call number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-transparent border-0 focus:outline-none text-slate-900 placeholder:text-slate-400"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="p-1 text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 border-t sm:border-t-0 sm:border-l border-slate-200 pt-2 sm:pt-0 sm:pl-3">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none"
              >
                <option value="all">All statuses</option>
                <option value="ready_for_pickup">Ready for pickup</option>
                <option value="borrowed">Borrowed</option>
                <option value="pending">Pending</option>
                <option value="returned">Returned</option>
                <option value="waitlisted">Waitlisted</option>
              </select>
            </div>
          </div>

          {/* Table matching Screenshot 526 */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3.5 px-5">STUDENT</th>
                    <th className="py-3.5 px-5">BOOK</th>
                    <th className="py-3.5 px-5">RESERVED</th>
                    <th className="py-3.5 px-5">DUE / PICK UP BY</th>
                    <th className="py-3.5 px-5">STATUS</th>
                    <th className="py-3.5 px-5 text-right">ACTION</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredReservations.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* Student */}
                      <td className="py-4 px-5">
                        <p className="font-bold text-slate-900">{item.studentName}</p>
                        <p className="text-[11px] text-slate-500 font-mono">{item.studentEmail}</p>
                      </td>

                      {/* Book */}
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={item.bookCover}
                            alt={item.bookTitle}
                            className="w-8 h-10 object-cover rounded bg-slate-100 shadow-2xs shrink-0 hidden sm:block"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <p className="font-semibold text-slate-900 line-clamp-1">{item.bookTitle}</p>
                            <p className="text-[11px] text-slate-500 font-mono">{item.callNumber}</p>
                          </div>
                        </div>
                      </td>

                      {/* Reserved */}
                      <td className="py-4 px-5 text-slate-600">
                        {item.reservationDate}
                      </td>

                      {/* Due / Pick up by */}
                      <td className="py-4 px-5">
                        <span className="font-semibold text-slate-900">
                          {item.pickupDeadline || item.dueDate}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-5">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded text-[11px] font-semibold ${
                            item.status === 'ready_for_pickup'
                              ? 'bg-amber-100 text-amber-800'
                              : item.status === 'borrowed'
                              ? 'bg-blue-100 text-blue-800'
                              : item.status === 'waitlisted'
                              ? 'bg-purple-100 text-purple-800'
                              : item.status === 'returned'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {item.status === 'pending'
                            ? 'Reserved'
                            : item.status === 'ready_for_pickup'
                            ? 'Ready for pickup'
                            : item.status.replace(/_/g, ' ')}
                        </span>
                      </td>

                      {/* Actions matching screenshot */}
                      <td className="py-4 px-5 text-right space-x-2">
                        {item.status === 'pending' && (
                          <button
                            type="button"
                            onClick={() => updateReservationStatus(item.id, 'ready_for_pickup')}
                            className="py-1.5 px-3 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs transition-colors"
                          >
                            Ready for pickup
                          </button>
                        )}

                        {item.status === 'ready_for_pickup' && (
                          <button
                            type="button"
                            onClick={() => updateReservationStatus(item.id, 'borrowed')}
                            className="py-1.5 px-3 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs transition-colors"
                          >
                            Mark borrowed
                          </button>
                        )}

                        {item.status === 'borrowed' && (
                          <button
                            type="button"
                            onClick={() => updateReservationStatus(item.id, 'returned')}
                            className="py-1.5 px-3 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg shadow-2xs transition-colors"
                          >
                            Mark returned
                          </button>
                        )}

                        {item.status === 'returned' && (
                          <span className="text-[11px] text-slate-400 italic">Closed</span>
                        )}

                        {item.status === 'waitlisted' && (
                          <span className="text-[11px] text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                            In Queue
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredReservations.length === 0 && (
              <div className="p-12 text-center text-slate-500 text-xs">
                No reservation or circulation records matched your search query.
              </div>
            )}
          </div>
        </div>
      )}

      {/* PAGE 3: BOOK INVENTORY SEPARATE PAGE */}
      {currentTab === 'inventory' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
                Book Inventory & Shelf Catalog
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-slate-500">
                Track availability copies, physical shelf locations, and add new volumes to shelves.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setTab('add-book')}
              className="flex items-center gap-1.5 py-2 px-4 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-xl self-start sm:self-auto transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>+ Add New Title</span>
            </button>
          </div>

          {/* Inventory Cards Grid matching screenshot bottom cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {books.map((book) => (
              <div
                key={book.id}
                onClick={() => onSelectBook(book)}
                className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-[#16325C]/40 transition-all flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-11 h-14 object-cover rounded bg-slate-100 shadow-2xs shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 group-hover:text-[#16325C] transition-colors line-clamp-1">
                      {book.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{book.author}</p>
                    <p className="text-[10px] font-mono text-slate-400 mt-0.5">{book.callNumber}</p>
                    <p className="text-[10px] text-slate-500 mt-1">{book.shelfLocation}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-bold text-emerald-600 font-mono bg-emerald-50 px-2.5 py-1 rounded-md">
                    {book.availableCopies}/{book.totalCopies} in
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PAGE 4: ADD BOOK SEPARATE PAGE */}
      {currentTab === 'add-book' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="pb-1">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
              Add Book to Catalog
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-500">
              Register a new collegiate textbook or reference volume into the LVCC library database.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 sm:p-8">
            <form onSubmit={handleCreateBook} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Book Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Database System Concepts"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Author(s) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Abraham Silberschatz"
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Category *
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Literature & Filipiniana">Literature & Filipiniana</option>
                    <option value="Accountancy & Business">Accountancy & Business</option>
                    <option value="Broadcasting & Media">Broadcasting & Media</option>
                    <option value="Law & Governance">Law & Governance</option>
                    <option value="Health & Nursing">Health & Nursing</option>
                    <option value="Social Sciences & Psychology">Social Sciences & Psychology</option>
                    <option value="General Education & Sciences">General Education & Sciences</option>
                    <option value="General Reference">General Reference</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Call / Book Number *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. QA 76.9 .D3 S55 2024"
                    value={newCallNumber}
                    onChange={(e) => setNewCallNumber(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C] font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Total Copies *
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={newCopies}
                    onChange={(e) => setNewCopies(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Shelf Location
                </label>
                <input
                  type="text"
                  placeholder="e.g. 2nd Floor - IT & Engineering (Shelf 4D)"
                  value={newShelf}
                  onChange={(e) => setNewShelf(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                />
              </div>

              {/* Book Picture Upload Section */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold text-slate-700">
                    Book Picture / Cover Image *
                  </label>
                  <span className="text-[11px] text-slate-500">
                    {isCustomUploaded ? 'Custom uploaded picture active' : 'Upload photo or choose preset'}
                  </span>
                </div>

                {uploadError && (
                  <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{uploadError}</span>
                  </div>
                )}

                {/* File Upload Zone */}
                <div className="p-4 bg-slate-50 border-2 border-dashed border-slate-300 rounded-xl hover:border-[#16325C]/50 transition-colors">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png, image/jpeg, image/webp"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="book-picture-upload"
                  />

                  {isCustomUploaded ? (
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-22 aspect-[3/4] bg-slate-200 rounded-lg overflow-hidden border border-slate-300 shadow-xs shrink-0">
                        <img
                          src={selectedCover}
                          alt="Custom uploaded book preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span>Book picture uploaded successfully!</span>
                        </div>
                        <p className="text-[11px] font-mono text-slate-500 truncate max-w-xs">
                          {uploadedFileName || 'custom-book-cover.jpg'}
                        </p>
                        <div className="flex items-center gap-2 pt-1">
                          <label
                            htmlFor="book-picture-upload"
                            className="text-xs font-semibold text-[#16325C] hover:underline cursor-pointer"
                          >
                            Upload Different Picture
                          </label>
                          <span className="text-slate-300">·</span>
                          <button
                            type="button"
                            onClick={handleRemoveCustomCover}
                            className="text-xs font-semibold text-rose-600 hover:underline"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <label
                      htmlFor="book-picture-upload"
                      className="flex flex-col items-center justify-center py-2 cursor-pointer text-center group"
                    >
                      <div className="w-10 h-10 rounded-full bg-white shadow-xs border border-slate-200 flex items-center justify-center text-[#16325C] mb-2 group-hover:scale-105 transition-transform">
                        <Upload className="w-5 h-5 text-[#16325C]" />
                      </div>
                      <p className="text-xs font-bold text-slate-800 group-hover:text-[#16325C]">
                        Upload book picture from your device
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Click here to browse PNG, JPG, or WEBP (up to 5MB)
                      </p>
                    </label>
                  )}
                </div>

                {/* Preset alternatives */}
                <div className="pt-1">
                  <p className="text-[11px] font-medium text-slate-600 mb-2">
                    Or select a collegiate textbook style preset:
                  </p>
                  <div className="grid grid-cols-4 gap-2.5">
                    {[
                      { label: 'Algorithms', url: '/src/assets/images/book_algorithms_cover_1793519863231.jpg' },
                      { label: 'Literature', url: '/src/assets/images/book_noli_me_tangere_1793519864481.jpg' },
                      { label: 'Craftsmanship', url: '/src/assets/images/book_clean_code_1793519863738.jpg' },
                      { label: 'Accounting', url: '/src/assets/images/book_accounting_principles_1793519863593.jpg' },
                    ].map((item) => (
                      <button
                        key={item.label}
                        type="button"
                        onClick={() => {
                          setSelectedCover(item.url);
                          setIsCustomUploaded(false);
                          setUploadedFileName('');
                        }}
                        className={`relative aspect-[3/4] rounded-lg overflow-hidden border-2 transition-all ${
                          !isCustomUploaded && selectedCover === item.url
                            ? 'border-[#16325C] shadow-sm ring-2 ring-[#16325C]/20 scale-102'
                            : 'border-slate-200 opacity-60 hover:opacity-90'
                        }`}
                      >
                        <img src={item.url} alt={item.label} className="w-full h-full object-cover" />
                        <span className="absolute bottom-0 inset-x-0 bg-black/60 text-white text-[9px] py-0.5 text-center truncate">
                          {item.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Synopsis / Academic Notes
                </label>
                <textarea
                  rows={3}
                  placeholder="Brief synopsis, textbook edition, or recommended semester coursework..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setTab('inventory')}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-xl shadow-sm transition-all"
                >
                  Save & Add to Catalog
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PDF Export Selection Modal */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4.5 border-b border-slate-100 bg-[#FAF9F5]">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#E5A827] flex items-center justify-center text-slate-900">
                  <FileDown className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#16325C]">Export Official PDF Report</h3>
                  <p className="text-[11px] text-slate-500">La Verdad Christian College Library System</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsExportModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Select Report to Export
                </h4>
                <p className="text-xs text-slate-500">
                  Choose which data section to compile into your downloadable PDF document:
                </p>
              </div>

              {/* 3 Selectable Report Cards */}
              <div className="space-y-2.5">
                {/* Option 1: Active Reservations & Borrowers List */}
                <label
                  onClick={() => setSelectedExportType('borrowers')}
                  className={`flex items-start gap-3.5 p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                    selectedExportType === 'borrowers'
                      ? 'border-[#16325C] bg-[#16325C]/5 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="reportType"
                    checked={selectedExportType === 'borrowers'}
                    onChange={() => setSelectedExportType('borrowers')}
                    className="mt-0.5 text-[#16325C] focus:ring-[#16325C]"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-[#16325C]" />
                      <span className="text-xs font-bold text-slate-900">
                        Active Reservations & Borrowers List
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Complete list of students who reserved or borrowed books, including student names, emails, call numbers, hold deadlines, return due dates, and circulation statuses.
                    </p>
                  </div>
                </label>

                {/* Option 2: Library Inventory Summary */}
                <label
                  onClick={() => setSelectedExportType('inventory')}
                  className={`flex items-start gap-3.5 p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                    selectedExportType === 'inventory'
                      ? 'border-[#16325C] bg-[#16325C]/5 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="reportType"
                    checked={selectedExportType === 'inventory'}
                    onChange={() => setSelectedExportType('inventory')}
                    className="mt-0.5 text-[#16325C] focus:ring-[#16325C]"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-3.5 h-3.5 text-[#16325C]" />
                      <span className="text-xs font-bold text-slate-900">
                        Library Inventory Summary
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Comprehensive shelf catalog overview detailing book titles, authors, categories, call numbers, physical campus shelf locations, and copies available in the library.
                    </p>
                  </div>
                </label>

                {/* Option 3: Both (Comprehensive Report) */}
                <label
                  onClick={() => setSelectedExportType('both')}
                  className={`flex items-start gap-3.5 p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                    selectedExportType === 'both'
                      ? 'border-[#16325C] bg-[#16325C]/5 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="reportType"
                    checked={selectedExportType === 'both'}
                    onChange={() => setSelectedExportType('both')}
                    className="mt-0.5 text-[#16325C] focus:ring-[#16325C]"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-[#16325C]" />
                      <span className="text-xs font-bold text-slate-900">
                        Both (Comprehensive Report)
                      </span>
                      <span className="text-[9px] font-bold text-[#996515] bg-[#D4A017]/20 px-1.5 py-0.5 rounded">
                        Recommended
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Full institutional multi-page PDF compiling both the active borrower circulation ledger and the complete shelf inventory catalog.
                    </p>
                  </div>
                </label>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="px-6 py-4 border-t border-slate-100 bg-[#FAF9F5] flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsExportModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200/60"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={() => {
                  exportCirculationPDF(selectedExportType);
                  setIsExportModalOpen(false);
                  setFeedbackNotice(
                    selectedExportType === 'borrowers'
                      ? 'Active Reservations & Borrowers List exported as PDF!'
                      : selectedExportType === 'inventory'
                      ? 'Library Inventory Summary exported as PDF!'
                      : 'Comprehensive Circulation & Inventory Report exported as PDF!'
                  );
                  setTimeout(() => setFeedbackNotice(null), 4000);
                }}
                className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-slate-950 bg-[#E5A827] hover:bg-[#d89c1f] rounded-xl shadow-sm transition-all active:scale-95"
              >
                <FileDown className="w-4 h-4" />
                <span>Download PDF Report</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

