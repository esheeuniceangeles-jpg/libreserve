import React, { useState } from 'react';
import { useLibrary } from '../context/LibraryContext';
import { Book } from '../types/library';
import {
  Search,
  GraduationCap,
  ShieldCheck,
  ArrowRight,
  BookOpen,
  Clock,
  MapPin,
  CheckCircle2,
  Calendar,
  Layers,
  HelpCircle,
  Sparkles,
} from 'lucide-react';

interface HomepageProps {
  onOpenAuth: (role?: 'student' | 'librarian') => void;
  onSelectBook: (book: Book) => void;
}

export const Homepage: React.FC<HomepageProps> = ({ onOpenAuth, onSelectBook }) => {
  const { books } = useLibrary();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = [
    'All',
    'Computer Science',
    'Literature & Filipiniana',
    'Accountancy & Business',
    'Broadcasting & Media',
    'Law & Governance',
    'Health & Nursing',
    'Social Sciences & Psychology',
    'General Education & Sciences'
  ];

  const filteredBooks = books.filter((b) => {
    const matchesCat = selectedCategory === 'All' || b.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesCat;
    return (
      matchesCat &&
      (b.title.toLowerCase().includes(query) ||
        b.author.toLowerCase().includes(query) ||
        b.callNumber.toLowerCase().includes(query))
    );
  });

  return (
    <div className="w-full">
      {/* Hero Section with LVCC Building Photo Background */}
      <section className="relative min-h-[580px] lg:min-h-[660px] flex items-center justify-center overflow-hidden">
        {/* Background photo of La Verdad Christian College */}
        <div className="absolute inset-0 z-0">
          <img
            src="/assets/aistudio/la_verdad_christian_college_d269243d.jpg"
            alt="La Verdad Christian College Campus Building"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Measured deep navy & slate scrim for contrast */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F203D]/95 via-[#16325C]/90 to-[#102444]/95" />
          <div className="absolute inset-0 bg-radial at-center from-transparent via-[#0B1728]/30 to-[#080F1A]/80" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-center">
          {/* Institutional Badge with Exclusive libreservelv Identifier */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-white text-xs font-medium mb-6">
            <span className="w-2 h-2 rounded-full bg-[#D4A017]" />
            <span className="font-mono font-semibold text-emerald-300">libreservelv</span>
            <span className="text-white/40">·</span>
            <span>La Verdad Christian College Library System</span>
          </div>

          {/* Main Title & Tagline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-tight">
            LibReserved <span className="text-[#D4A017]">LV</span>
          </h1>

          <p className="mt-4 text-xl sm:text-2xl font-light text-slate-200 tracking-wide italic">
            “Reserved, Borrow, and Learned.”
          </p>

          <p className="mt-4 text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Welcome to the official online library reservation portal for LVCC students and faculty.
            Search physical volumes, reserve available titles with a 5-slot allowance, and track real-time reservation and borrowing statuses.
          </p>

          {/* Separate Portals Entrance Cards */}
          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-5 max-w-3xl mx-auto text-left">
            {/* Student Portal Card */}
            <div className="p-6 rounded-2xl bg-white/95 backdrop-blur-md border border-white/20 shadow-xl hover:shadow-2xl transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#16325C]/10 flex items-center justify-center text-[#16325C]">
                    <GraduationCap className="w-5 h-5 text-[#16325C]" />
                  </div>
                  <span className="text-[11px] font-semibold text-[#16325C] bg-[#16325C]/5 px-2.5 py-1 rounded-md">
                    LVCC Students
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#16325C] transition-colors">
                  Student Reservation Portal
                </h3>
                <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                  Sign in with your @student.laverdad.edu.ph account. Reserve up to 5 books, join waitlists for checked-out items, and receive due date notifications.
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-medium text-slate-500">5 Active Slots Available</span>
                <button
                  type="button"
                  onClick={() => onOpenAuth('student')}
                  className="flex items-center gap-1.5 py-2 px-3.5 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-lg transition-all shadow-sm group-hover:translate-x-0.5"
                >
                  <span>Student Sign In</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#D4A017]" />
                </button>
              </div>
            </div>

            {/* Librarian Portal Card */}
            <div className="p-6 rounded-2xl bg-white/95 backdrop-blur-md border border-white/20 shadow-xl hover:shadow-2xl transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#D4A017]/15 flex items-center justify-center text-[#996515]">
                    <ShieldCheck className="w-5 h-5 text-[#B8860B]" />
                  </div>
                  <span className="text-[11px] font-semibold text-[#996515] bg-[#D4A017]/10 px-2.5 py-1 rounded-md">
                    Staff Only
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#16325C] transition-colors">
                  Librarian Circulation Portal
                </h3>
                <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                  Authorized staff access for circulation management, issuing checkouts, receiving returns, catalog management, and PDF report generation.
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-medium text-slate-500">Requires Staff Auth</span>
                <button
                  type="button"
                  onClick={() => onOpenAuth('librarian')}
                  className="flex items-center gap-1.5 py-2 px-3.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-all shadow-sm"
                >
                  <span>Librarian Portal</span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog Live Search & Preview Section */}
      <section id="catalog-preview" className="py-16 bg-[#FAF9F5] border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#16325C] tracking-tight">
              Explore LVCC Library Catalog
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Browse textbooks, literature, and general references available at our campus library shelves.
            </p>
          </div>

          {/* Search Box Bar matching screenshot */}
          <div className="max-w-3xl mx-auto mb-8">
            <div className="flex flex-col sm:flex-row gap-2 p-2 bg-white rounded-2xl shadow-sm border border-slate-200">
              <div className="relative flex-1 flex items-center">
                <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by title, author, or book number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-transparent border-0 focus:outline-none text-slate-900 placeholder:text-slate-400"
                />
              </div>

              <div className="flex items-center gap-2 border-t sm:border-t-0 sm:border-l border-slate-200 pt-2 sm:pt-0 sm:pl-3">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => onOpenAuth('student')}
                  className="whitespace-nowrap px-4 py-2 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-lg transition-colors"
                >
                  Reserve Now
                </button>
              </div>
            </div>
          </div>

          {/* Book Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredBooks.slice(0, 8).map((book) => (
              <div
                key={book.id}
                onClick={() => onSelectBook(book)}
                className="group bg-white rounded-xl border border-slate-200 hover:border-[#16325C]/40 shadow-sm hover:shadow-md transition-all flex flex-col overflow-hidden cursor-pointer"
              >
                {/* Book Cover Image */}
                <div className="relative aspect-[3/4] bg-slate-100 overflow-hidden">
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2.5 right-2.5">
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded shadow-sm ${
                        book.availableCopies > 0
                          ? 'bg-emerald-600 text-white'
                          : 'bg-amber-600 text-white'
                      }`}
                    >
                      {book.availableCopies > 0
                        ? `${book.availableCopies}/${book.totalCopies} in`
                        : 'Waitlist'}
                    </span>
                  </div>
                </div>

                {/* Book Info */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-[11px] font-mono text-slate-500 mb-1">{book.callNumber}</p>
                    <h3 className="text-sm font-bold text-slate-900 group-hover:text-[#16325C] transition-colors line-clamp-1">
                      {book.title}
                    </h3>
                    <p className="text-xs text-slate-600 mt-0.5 line-clamp-1">{book.author}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">{book.category.split('&')[0]}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenAuth('student');
                      }}
                      className="text-xs font-semibold text-[#16325C] hover:text-[#D4A017] transition-colors"
                    >
                      {book.availableCopies > 0 ? 'Reserve →' : 'Waitlist →'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-wider text-[#D4A017]">
              Simple & Efficient
            </span>
            <h2 className="mt-1 text-2xl sm:text-3xl font-bold text-[#16325C] tracking-tight">
              How LibReserved LV Works
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Three seamless steps from catalog discovery to classroom learning.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 relative">
              <div className="w-10 h-10 rounded-xl bg-[#16325C] text-white flex items-center justify-center font-bold text-sm mb-4">
                01
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Search Catalog</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Look up required readings by book title, author, subject, or Dewey/LC call number. View shelf locations in the LVCC library.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 relative">
              <div className="w-10 h-10 rounded-xl bg-[#D4A017] text-white flex items-center justify-center font-bold text-sm mb-4">
                02
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Reserve or Join Waitlist</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Click reserve to hold an available copy using one of your 5 allocated slots. If out of stock, join the waitlist queue automatically.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 relative">
              <div className="w-10 h-10 rounded-xl bg-[#16325C] text-white flex items-center justify-center font-bold text-sm mb-4">
                03
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Pick Up & Learn</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Head to the LVCC Circulation Desk at Apalit Campus within 3 days. Receive automated return reminders before your due date.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5-Slot Borrowing Policy Section */}
      <section id="reservation-slots" className="py-16 bg-[#FAF9F5] border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#16325C]">
                Student Privileges
              </span>
              <h2 className="mt-1 text-2xl sm:text-3xl font-bold text-[#16325C] tracking-tight">
                The 5-Slot Book Reservation Policy
              </h2>
              <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                To guarantee equal academic resource access across all departments, every registered La Verdad Christian College student is granted five concurrent reservation/borrowing slots.
              </p>

              <div className="mt-6 space-y-3.5">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <p className="text-xs text-slate-700">
                    <strong className="text-slate-900">5 Simultaneous Slots:</strong> Hold or borrow up to 5 books across IT, Accountancy, AB Broadcasting, and General Education.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <p className="text-xs text-slate-700">
                    <strong className="text-slate-900">3-Day Hold Window:</strong> Reserved items are stored at the circulation desk for 72 hours before release.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <p className="text-xs text-slate-700">
                    <strong className="text-slate-900">Due Date Reminders:</strong> Automated notifications alert you 2 days prior to your return deadline.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <p className="text-xs text-slate-700">
                    <strong className="text-slate-900">Automatic Slot Reclamation:</strong> Returning a book instantly frees up a slot for your next research topic.
                  </p>
                </div>
              </div>

              <div className="mt-8">
                <button
                  type="button"
                  onClick={() => onOpenAuth('student')}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-lg shadow-sm transition-all"
                >
                  Check Your Available Slots
                </button>
              </div>
            </div>

            {/* Visual 5-Slot Demonstration Card */}
            <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#16325C]" />
                  <h4 className="text-sm font-bold text-slate-900">Student Slots Breakdown</h4>
                </div>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                  Standard Account
                </span>
              </div>

              <div className="mt-4 space-y-2.5">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#16325C] text-white flex items-center justify-center text-[10px] font-bold">1</span>
                    <span className="font-medium text-slate-800">Introduction to Algorithms</span>
                  </div>
                  <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                    Ready for pickup
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#16325C] text-white flex items-center justify-center text-[10px] font-bold">2</span>
                    <span className="font-medium text-slate-800">Principles of Accounting</span>
                  </div>
                  <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                    Borrowed (Due Nov 8)
                  </span>
                </div>

                {[3, 4, 5].map((slotNum) => (
                  <div
                    key={slotNum}
                    className="p-3 border border-dashed border-slate-300 rounded-xl flex items-center justify-between text-xs text-slate-400"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-[10px] font-medium">
                        {slotNum}
                      </span>
                      <span>Slot Available</span>
                    </div>
                    <span className="text-[10px] uppercase tracking-wider text-emerald-600 font-semibold">
                      Empty
                    </span>
                  </div>
                ))}
              </div>

              <p className="mt-4 text-[11px] text-slate-500 text-center">
                Maximum 5 physical items simultaneously reserved or borrowed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Library Hours & Desk Section */}
      <section id="library-hours" className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#16325C] tracking-tight">
              Campus Library Information
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Visit our physical circulation counters at La Verdad Christian College.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="w-10 h-10 rounded-xl bg-[#16325C]/10 flex items-center justify-center text-[#16325C] mb-4">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 mb-1">Operating Hours</h3>
              <p className="text-xs text-slate-600 mb-2">Circulation & Reading Rooms</p>
              <div className="space-y-1 text-xs text-slate-700">
                <p><span className="font-semibold text-slate-900">Mon - Fri:</span> 7:30 AM – 6:00 PM</p>
                <p><span className="font-semibold text-slate-900">Saturday:</span> Closed (Study Review)</p>
                <p><span className="font-semibold text-slate-900">Sunday:</span> 8:00 AM – 12:00 PM</p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="w-10 h-10 rounded-xl bg-[#D4A017]/15 flex items-center justify-center text-[#996515] mb-4">
                <MapPin className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 mb-1">Campus Location</h3>
              <p className="text-xs text-slate-600 mb-2">Main Academic Complex</p>
              <p className="text-xs text-slate-700 leading-relaxed">
                2nd & 3rd Floors, La Verdad Christian College Complex, MacArthur Highway, Sampaloc, Apalit, Pampanga 2016, Philippines.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="w-10 h-10 rounded-xl bg-[#16325C]/10 flex items-center justify-center text-[#16325C] mb-4">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 mb-1">Circulation Counters</h3>
              <p className="text-xs text-slate-600 mb-2">Pickup & Reference Assistance</p>
              <p className="text-xs text-slate-700 leading-relaxed">
                Counter 1: General Reserve & Pickups<br />
                Counter 2: Filipiniana & Theses Archive<br />
                Counter 3: Faculty & IT Reference Desk
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About LVCC Section */}
      <section id="about-lvcc" className="py-16 bg-[#FAF9F5]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-[#16325C] tracking-tight">
            About LibReserved LV
          </h2>
          <p className="mt-4 text-sm text-slate-600 leading-relaxed">
            LibReserved LV is the official digital circulation and reservation platform engineered for La Verdad Christian College.
            Built with modern web standards and tailored to institutional library workflows, LibReserved LV bridges students with collegiate literature, technical volumes, and academic research materials.
          </p>

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => onOpenAuth('student')}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-lg shadow-sm transition-all"
            >
              Log In as a Student
            </button>
            <button
              type="button"
              onClick={() => onOpenAuth('librarian')}
              className="px-5 py-2.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg shadow-sm transition-all"
            >
              Log In as a Librarian
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
