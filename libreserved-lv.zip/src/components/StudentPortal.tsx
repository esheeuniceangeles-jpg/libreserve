import React, { useState } from 'react';
import { useLibrary } from '../context/LibraryContext';
import { Book, Reservation } from '../types/library';
import {
  Search,
  BookOpen,
  Clock,
  CheckCircle,
  AlertCircle,
  X,
  Bookmark,
  Bell,
  Layers,
  ChevronRight,
  Info,
  Calendar,
  MapPin,
  Sparkles,
} from 'lucide-react';

interface StudentPortalProps {
  currentTab: 'find-books' | 'my-reservations' | 'overview' | 'notifications';
  setTab: (tab: 'find-books' | 'my-reservations' | 'overview' | 'notifications') => void;
  onSelectBook: (book: Book) => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({ currentTab, setTab, onSelectBook }) => {
  const {
    currentUser,
    books,
    reservations,
    notifications,
    reserveBook,
    cancelReservation,
    markNotificationAsRead,
    clearAllNotifications,
  } = useLibrary();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [reservationMessage, setReservationMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Student specific reservations
  const studentReservations = reservations.filter(
    (r) => r.studentEmail?.toLowerCase() === currentUser?.email?.toLowerCase()
  );

  const activeReservations = studentReservations.filter((r) =>
    ['pending', 'ready_for_pickup'].includes(r.status)
  );

  const readyForPickup = studentReservations.filter((r) => r.status === 'ready_for_pickup');
  const currentlyBorrowed = studentReservations.filter((r) => r.status === 'borrowed');
  const waitlisted = studentReservations.filter((r) => r.status === 'waitlisted');

  // Total active slots used (out of 5)
  const totalSlotsUsed = studentReservations.filter((r) =>
    ['pending', 'ready_for_pickup', 'borrowed', 'waitlisted'].includes(r.status)
  ).length;

  const slotsLeft = Math.max(0, 5 - totalSlotsUsed);

  // Filter books
  const categories = [
    'All',
    'Computer Science',
    'Literature & Filipiniana',
    'Accountancy & Business',
    'Broadcasting & Media',
    'Law & Governance',
    'Health & Nursing',
    'Social Sciences & Psychology',
    'General Education & Sciences'
  ];

  const filteredBooks = books.filter((b) => {
    const matchesCat = selectedCategory === 'All' || b.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesCat;
    return (
      matchesCat &&
      (b.title.toLowerCase().includes(query) ||
        b.author.toLowerCase().includes(query) ||
        b.callNumber.toLowerCase().includes(query))
    );
  });

  const handleReserve = (bookId: string) => {
    const res = reserveBook(bookId);
    if (res.success) {
      setReservationMessage({ type: 'success', text: res.message });
    } else {
      setReservationMessage({ type: 'error', text: res.message });
    }
    setTimeout(() => {
      setReservationMessage(null);
    }, 5000);
  };

  const studentName =
    currentUser?.name?.split(' ')[0] ||
    (currentUser?.email ? currentUser.email.split('@')[0] : 'Student');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4 sm:space-y-6">
      {/* Toast Notification message */}
      {reservationMessage && (
        <div
          className={`p-3.5 rounded-xl border flex items-center justify-between text-xs font-semibold shadow-md transition-all ${
            reservationMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
              : 'bg-amber-50 border-amber-300 text-amber-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {reservationMessage.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            )}
            <span>{reservationMessage.text}</span>
          </div>
          <button
            onClick={() => setReservationMessage(null)}
            className="p-1 hover:bg-black/5 rounded-md"
            aria-label="Close notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* PAGE 1: FIND BOOKS / BROWSE CATALOG PAGE */}
      {currentTab === 'find-books' && (
        <div className="space-y-4">
          {/* Upper Search Box: Streamlined & compact so books are immediately visible above fold */}
          <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#D4A017]" />
                <h1 className="text-sm sm:text-base font-bold text-[#16325C]">
                  Catalog Search
                </h1>
              </div>
              <span className="text-[11px] text-slate-500 hidden sm:inline">
                Reserve up to 5 books with instant hold
              </span>
            </div>

            {/* Search Input Bar */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1 flex items-center">
                <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  aria-label="Search books by title, author, or call number"
                  placeholder="Search by title (e.g. Algorithms, Noli, React), author, or call number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#16325C] text-slate-900 placeholder:text-slate-400 transition-all"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 p-1 text-slate-400 hover:text-slate-600 rounded-md"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <select
                  aria-label="Filter by book category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="text-xs sm:text-sm font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#16325C]"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {searchQuery && (
              <p className="text-xs text-[#16325C] font-medium flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
                Results for "{searchQuery}"
              </p>
            )}
          </div>

          {/* Book Catalog Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredBooks.map((book) => {
              const userActiveBookRes = studentReservations.find(
                (r) => r.bookId === book.id && ['pending', 'ready_for_pickup', 'borrowed', 'waitlisted'].includes(r.status)
              );

              return (
                <div
                  key={book.id}
                  onClick={() => onSelectBook(book)}
                  className="group bg-white rounded-xl border border-slate-200 hover:border-[#16325C]/40 shadow-xs hover:shadow-md transition-all flex flex-col overflow-hidden cursor-pointer"
                >
                  {/* Book Image */}
                  <div className="relative aspect-[3/4] bg-slate-100 overflow-hidden">
                    <img
                      src={book.coverImage}
                      alt={book.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />

                    {/* Badge */}
                    <div className="absolute top-2.5 right-2.5">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded shadow-xs ${
                          book.availableCopies > 0
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-600 text-white'
                        }`}
                      >
                        {book.availableCopies > 0
                          ? `${book.availableCopies}/${book.totalCopies} in`
                          : 'Waitlist'}
                      </span>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-[11px] font-mono text-slate-500 mb-1">{book.callNumber}</p>
                      <h3 className="text-sm font-bold text-slate-900 group-hover:text-[#16325C] transition-colors line-clamp-1">
                        {book.title}
                      </h3>
                      <p className="text-xs text-slate-600 mt-0.5 line-clamp-1">{book.author}</p>
                      <p className="text-[11px] text-slate-400 mt-2 line-clamp-2">
                        {book.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[11px] text-slate-500">{book.category.split('&')[0]}</span>

                      {userActiveBookRes ? (
                        <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          {userActiveBookRes.status.replace(/_/g, ' ')}
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleReserve(book.id);
                          }}
                          className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                            book.availableCopies > 0
                              ? 'text-white bg-[#16325C] hover:bg-[#1a3d6f]'
                              : 'text-amber-800 bg-amber-100 hover:bg-amber-200'
                          }`}
                        >
                          {book.availableCopies > 0 ? 'Reserve' : 'Join Waitlist'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredBooks.length === 0 && (
            <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
              <BookOpen className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-800">No matching books found</h3>
              <p className="text-xs text-slate-500 mt-1">
                Try searching with different keywords or selecting "All" categories.
              </p>
            </div>
          )}
        </div>
      )}

      {/* PAGE 2: MY RESERVATIONS SEPARATE PAGE */}
      {currentTab === 'my-reservations' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
                My Book Reservations & Borrowed Books
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Monitor pickup schedules, borrowed books, and waitlist progress for your account.
              </p>
            </div>

            <button
              onClick={() => setTab('find-books')}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-xl self-start sm:self-auto transition-all"
            >
              + Reserve Another Book
            </button>
          </div>

          {/* Quick status summary bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-medium">Ready for Pickup</p>
              <p className="text-2xl font-bold font-mono text-emerald-600 mt-1">{readyForPickup.length}</p>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-medium">Currently Borrowed</p>
              <p className="text-2xl font-bold font-mono text-blue-600 mt-1">{currentlyBorrowed.length}</p>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-medium">Waitlisted</p>
              <p className="text-2xl font-bold font-mono text-purple-600 mt-1">{waitlisted.length}</p>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-medium">Slots Remaining</p>
              <p className="text-2xl font-bold font-mono text-[#16325C] mt-1">{slotsLeft} of 5</p>
            </div>
          </div>

          {studentReservations.length === 0 ? (
            <div className="p-16 text-center bg-white rounded-2xl border border-slate-200">
              <Bookmark className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">No active book reservations</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                You have not placed any holds yet. Visit the catalog to find readings and reserve copies using your 5 available slots.
              </p>
              <button
                onClick={() => setTab('find-books')}
                className="mt-4 px-5 py-2.5 text-xs font-semibold text-white bg-[#16325C] rounded-lg"
              >
                Browse Books Catalog
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF9F5] border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3.5 px-5">Book Details</th>
                      <th className="py-3.5 px-5">Call Number</th>
                      <th className="py-3.5 px-5">Reserved Date</th>
                      <th className="py-3.5 px-5">Due / Pick Up By</th>
                      <th className="py-3.5 px-5">Status</th>
                      <th className="py-3.5 px-5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {studentReservations.map((res) => (
                      <tr key={res.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-4 px-5">
                          <div className="flex items-center gap-3">
                            <img
                              src={res.bookCover}
                              alt={res.bookTitle}
                              className="w-9 h-12 object-cover rounded bg-slate-100 shadow-2xs shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <p className="font-bold text-slate-900 line-clamp-1">{res.bookTitle}</p>
                              <p className="text-slate-500 text-[11px] line-clamp-1">{res.bookAuthor}</p>
                            </div>
                          </div>
                        </td>

                        <td className="py-4 px-5 font-mono text-slate-600">
                          {res.callNumber}
                        </td>

                        <td className="py-4 px-5 text-slate-600">
                          {res.reservationDate}
                        </td>

                        <td className="py-4 px-5">
                          <span className="font-semibold text-slate-900">
                            {res.pickupDeadline || res.dueDate}
                          </span>
                        </td>

                        <td className="py-4 px-5">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-semibold ${
                              res.status === 'ready_for_pickup'
                                ? 'bg-amber-100 text-amber-800'
                                : res.status === 'borrowed'
                                ? 'bg-blue-100 text-blue-800'
                                : res.status === 'waitlisted'
                                ? 'bg-purple-100 text-purple-800'
                                : res.status === 'returned'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {res.status === 'ready_for_pickup' && <CheckCircle className="w-3 h-3" />}
                            {res.status === 'waitlisted' && <Clock className="w-3 h-3" />}
                            {res.status.replace(/_/g, ' ')}
                            {res.waitlistPosition && ` (#${res.waitlistPosition})`}
                          </span>
                        </td>

                        <td className="py-4 px-5 text-right">
                          {['pending', 'ready_for_pickup', 'waitlisted'].includes(res.status) && (
                            <button
                              type="button"
                              onClick={() => cancelReservation(res.id)}
                              className="text-xs font-semibold text-rose-600 hover:text-rose-800 hover:underline"
                            >
                              Cancel Hold
                            </button>
                          )}
                          {res.status === 'borrowed' && (
                            <span className="text-[11px] text-slate-500 font-medium">
                              Currently Borrowed
                            </span>
                          )}
                          {res.status === 'returned' && (
                            <span className="text-[11px] text-emerald-600 font-medium">
                              Completed
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* PAGE 3: OVERVIEW & 5 SLOTS SEPARATE PAGE */}
      {currentTab === 'overview' && (
        <div className="space-y-6">
          <div className="pb-1">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
              Reservation Overview & 5-Slot Allocation
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-500">
              Hello {studentName}, here is the status of your library privileges and current reservations.
            </p>
          </div>

          {/* 4 Dashboard Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div
              onClick={() => setTab('my-reservations')}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-500">Active reservations</p>
                <Bookmark className="w-4 h-4 text-[#D4A017] transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {activeReservations.length}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Pending and holds</p>
            </div>

            <div
              onClick={() => setTab('my-reservations')}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-500">Ready for pickup</p>
                <CheckCircle className="w-4 h-4 text-emerald-600 transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {readyForPickup.length}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Prepared at Counter 1</p>
            </div>

            <div
              onClick={() => setTab('my-reservations')}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-[#16325C]/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-500">Borrowed</p>
                <BookOpen className="w-4 h-4 text-[#16325C] transition-transform group-hover:scale-110" />
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {currentlyBorrowed.length}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Free campus borrowing</p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-500">Slots left (max 5)</p>
                <span className="w-4 h-4 rounded-full border border-slate-300 flex items-center justify-center text-[10px] text-slate-500 font-bold">
                  +
                </span>
              </div>
              <p className="mt-3 text-3xl font-bold font-mono text-slate-900 tabular-nums">
                {slotsLeft}
              </p>
              <p className="text-[11px] text-emerald-600 font-medium mt-1">{slotsLeft} available for new requests</p>
            </div>
          </div>

          {/* 5-Slot Allocation Status Overview Card */}
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <Layers className="w-5 h-5 text-[#16325C]" />
                <div>
                  <h2 className="text-base font-bold text-slate-900">5-Slot Allocation Status Tracker</h2>
                  <p className="text-xs text-slate-500">
                    You are utilizing {totalSlotsUsed} of your 5 allowed LVCC reservation slots.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 self-start sm:self-auto">
                <span className="text-xs font-mono font-bold text-[#16325C] bg-[#16325C]/10 px-2.5 py-1 rounded-md">
                  {slotsLeft} Available
                </span>
                <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md">
                  {totalSlotsUsed} Used
                </span>
              </div>
            </div>

            {/* 5 Individual Slots Visual Grid */}
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-5 gap-3">
              {[0, 1, 2, 3, 4].map((slotIdx) => {
                const reservationItem = studentReservations[slotIdx];
                const isUsed = !!reservationItem && ['pending', 'ready_for_pickup', 'borrowed', 'waitlisted'].includes(reservationItem.status);

                return (
                  <div
                    key={slotIdx}
                    className={`p-3.5 rounded-xl border transition-all ${
                      isUsed
                        ? 'bg-slate-50 border-slate-200 shadow-2xs'
                        : 'bg-white border-dashed border-slate-300 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          isUsed
                            ? 'bg-[#16325C] text-white'
                            : 'bg-slate-100 text-slate-400'
                        }`}
                      >
                        {slotIdx + 1}
                      </span>

                      {isUsed && (
                        <span
                          className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                            reservationItem.status === 'ready_for_pickup'
                              ? 'bg-amber-100 text-amber-800'
                              : reservationItem.status === 'borrowed'
                              ? 'bg-blue-100 text-blue-800'
                              : reservationItem.status === 'waitlisted'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-slate-200 text-slate-800'
                          }`}
                        >
                          {reservationItem.status.replace(/_/g, ' ')}
                        </span>
                      )}
                    </div>

                    {isUsed ? (
                      <div>
                        <p className="text-xs font-bold text-slate-900 line-clamp-1">
                          {reservationItem.bookTitle}
                        </p>
                        <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                          {reservationItem.bookAuthor}
                        </p>
                        <p className="text-[10px] font-mono text-slate-600 mt-2">
                          {reservationItem.status === 'ready_for_pickup'
                            ? `Pick up by ${reservationItem.pickupDeadline}`
                            : reservationItem.status === 'borrowed'
                            ? `Due ${reservationItem.dueDate}`
                            : `Req ${reservationItem.reservationDate}`}
                        </p>
                      </div>
                    ) : (
                      <div className="py-2 text-center">
                        <p className="text-xs font-medium text-slate-400">Available Slot</p>
                        <p className="text-[10px] text-slate-400 mt-1">Ready for reserve</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Policy Information Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Free Borrowing Privileges
              </h3>
              <div className="space-y-3 text-xs">
                <div className="flex justify-between pb-2 border-b border-slate-100">
                  <span className="text-slate-600">Total Slot Allowance:</span>
                  <span className="font-bold text-slate-900 font-mono">5 Books</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-slate-100">
                  <span className="text-slate-600">Slots Currently In Use:</span>
                  <span className="font-bold text-[#16325C] font-mono">{totalSlotsUsed}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-slate-100">
                  <span className="text-slate-600">Available Slots:</span>
                  <span className="font-bold text-emerald-600 font-mono">{slotsLeft}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Borrowing Period (100% Free):</span>
                  <span className="font-bold text-slate-900">7 to 14 Days</span>
                </div>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Pickup Rules
              </h3>
              <div className="space-y-2 text-xs text-slate-600 leading-relaxed">
                <p>
                  • Reserved books must be picked up within <strong>72 hours</strong> of preparation.
                </p>
                <p>
                  • Please present your official <strong>LVCC Student ID card</strong> at Counter 1.
                </p>
                <p>
                  • Unclaimed holds will automatically be cancelled and released to the next student.
                </p>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Campus Circulation Desk
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-3">
                Main Academic Complex, Apalit, Pampanga.
              </p>
              <div className="text-[11px] text-slate-500 space-y-1">
                <p>Email: library@laverdad.edu.ph</p>
                <p>Hours: Mon-Fri 7:30 AM – 6:00 PM</p>
                <p>Sunday: 8:00 AM – 12:00 PM</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PAGE 4: DUE DATE NOTIFICATIONS SEPARATE PAGE */}
      {currentTab === 'notifications' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16325C] tracking-tight">
                Due Date & Reservation Notifications
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Reminders about return due dates, ready-for-pickup notices, and waitlist advancements.
              </p>
            </div>
            {notifications.length > 0 && (
              <button
                type="button"
                onClick={clearAllNotifications}
                className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50"
              >
                Clear All
              </button>
            )}
          </div>

          <div className="space-y-3">
            {notifications
              .filter((n) => !currentUser || n.studentEmail === currentUser.email)
              .map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => markNotificationAsRead(notif.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    notif.read
                      ? 'bg-white border-slate-200'
                      : 'bg-amber-50/70 border-amber-200 shadow-2xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                          notif.type === 'ready_pickup'
                            ? 'bg-amber-100 text-amber-800'
                            : notif.type === 'due_date'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        <Bell className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-900">{notif.title}</h4>
                          {!notif.read && (
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                          )}
                        </div>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">{notif.message}</p>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400 shrink-0">
                      {notif.timestamp}
                    </span>
                  </div>
                </div>
              ))}

            {notifications.filter((n) => !currentUser || n.studentEmail === currentUser.email).length === 0 && (
              <div className="p-16 text-center bg-white rounded-2xl border border-slate-200">
                <Bell className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-800">No active notifications</h3>
                <p className="text-xs text-slate-500 mt-1">
                  You are all caught up on your library pickup schedules and return deadlines!
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
