import React from 'react';
import { useLibrary } from '../context/LibraryContext';
import { MapPin, Phone, Mail, Clock, ShieldCheck, GraduationCap } from 'lucide-react';

interface FooterProps {
  onOpenAuth: (role?: 'student' | 'librarian') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAuth }) => {
  const { setActiveView } = useLibrary();

  return (
    <footer className="w-full bg-[#102444] text-slate-300 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Col 1: Brand & Tagline */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-white rounded-lg shadow-sm">
                <img
                  src="/assets/aistudio/850698335_2226256467988917_3141871878674636534_n_dcf2d853.jpg"
                  alt="LibReserved LV"
                  className="h-8 w-auto object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <p className="text-slate-300 italic text-xs">
              “Reserved, Borrow, and Learned.”
            </p>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              The automated library reservation and circulation tracking system of La Verdad Christian College.
            </p>
          </div>

          {/* Col 2: Campus Circulation Desks */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Campus Library
            </h4>
            <div className="space-y-2 text-[11px] text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#D4A017] shrink-0 mt-0.5" />
                <span>MacArthur Hwy, Sampaloc, Apalit, Pampanga 2016</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>Mon - Fri: 7:30 AM – 6:00 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>library@laverdad.edu.ph</span>
              </div>
            </div>
          </div>

          {/* Col 3: Separate Portals */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Portals & Services
            </h4>
            <ul className="space-y-2 text-[11px]">
              <li>
                <button
                  type="button"
                  onClick={() => onOpenAuth('student')}
                  className="flex items-center gap-1.5 hover:text-white transition-colors"
                >
                  <GraduationCap className="w-3.5 h-3.5 text-[#D4A017]" />
                  <span>Student Book Reservation Portal</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenAuth('librarian')}
                  className="flex items-center gap-1.5 hover:text-white transition-colors"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
                  <span>Librarian Circulation Portal</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setActiveView('home')}
                  className="hover:text-white transition-colors"
                >
                  5-Slot Borrowing Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setActiveView('home')}
                  className="hover:text-white transition-colors"
                >
                  Catalog Dewey & LC Decimal Guide
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: LVCC Commitment */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              La Verdad Christian College
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Excellence in Christian education, research integrity, and accessible knowledge resources for every scholar.
            </p>
            <div className="pt-1">
              <span className="inline-block px-2.5 py-1 rounded bg-white/5 border border-white/10 text-[10px] font-mono text-slate-300">
                Official Circulation Portal
              </span>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>© 2026 La Verdad Christian College · LibReserved LV. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => setActiveView('home')} className="hover:text-slate-400">Homepage</button>
            <span>·</span>
            <span className="text-slate-400">Tagline: “Reserved, Borrow, and Learned.”</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
