import React, { createContext, useContext, useState, useEffect } from 'react';
import { Book, Reservation, LibraryNotification, User, UserRole, ReservationStatus, ExportReportType } from '../types/library';
import { INITIAL_BOOKS, INITIAL_RESERVATIONS, INITIAL_NOTIFICATIONS } from '../data/initialData';
import { jsPDF } from 'jspdf';

interface LibraryContextType {
  currentUser: User | null;
  books: Book[];
  reservations: Reservation[];
  notifications: LibraryNotification[];
  login: (email: string, role: UserRole, password: string, customName?: string, isNewAccount?: boolean) => { success: boolean; error?: string };
  logout: () => void;
  reserveBook: (bookId: string) => { success: boolean; message: string };
  cancelReservation: (reservationId: string) => void;
  updateReservationStatus: (reservationId: string, newStatus: ReservationStatus) => void;
  addBook: (newBook: Omit<Book, 'id'>) => void;
  updateBook: (id: string, updates: Partial<Book>) => void;
  deleteBook: (id: string) => void;
  markNotificationAsRead: (id: string) => void;
  clearAllNotifications: () => void;
  exportCirculationPDF: (reportType?: ExportReportType) => void;
  activeView: 'home' | 'student' | 'librarian';
  setActiveView: (view: 'home' | 'student' | 'librarian') => void;
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

export const LibraryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('libreserved_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Registered user accounts with their custom passwords
  const [registeredAccounts, setRegisteredAccounts] = useState<Record<string, User>>(() => {
    const saved = localStorage.getItem('libreserved_registered_accounts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    // Default initial accounts with sample passwords
    return {
      'esheeunice.angeles@student.laverdad.edu.ph': {
        id: 'stud-1',
        name: 'Esheeunice Angeles',
        email: 'esheeunice.angeles@student.laverdad.edu.ph',
        role: 'student',
        password: 'password123',
        studentNumber: 'LVCC-2024-0824',
        department: 'BS Information Technology',
      },
      'maria.santo@laverdad.edu.ph': {
        id: 'lib-1',
        name: 'Maria Santo',
        email: 'maria.santo@laverdad.edu.ph',
        role: 'librarian',
        password: 'password123',
        department: 'LVCC Main Library & Circulation Office',
      },
    };
  });

  useEffect(() => {
    localStorage.setItem('libreserved_registered_accounts', JSON.stringify(registeredAccounts));
  }, [registeredAccounts]);

  const [books, setBooks] = useState<Book[]>(() => {
    const saved = localStorage.getItem('libreserved_books');
    if (saved) {
      try {
        const parsed: Book[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const initialMap = new Map(INITIAL_BOOKS.map((b) => [b.id, b]));
          // Keep custom books added by librarian
          const customBooks = parsed.filter((b) => !initialMap.has(b.id));
          return [...INITIAL_BOOKS, ...customBooks];
        }
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_BOOKS;
  });

  const [reservations, setReservations] = useState<Reservation[]>(() => {
    const saved = localStorage.getItem('libreserved_reservations');
    return saved ? JSON.parse(saved) : INITIAL_RESERVATIONS;
  });

  const [notifications, setNotifications] = useState<LibraryNotification[]>(() => {
    const saved = localStorage.getItem('libreserved_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [activeView, setActiveView] = useState<'home' | 'student' | 'librarian'>(() => {
    const saved = localStorage.getItem('libreserved_user');
    if (saved) {
      const u: User = JSON.parse(saved);
      return u.role === 'librarian' ? 'librarian' : 'student';
    }
    return 'home';
  });

  // Local storage persistence
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('libreserved_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('libreserved_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('libreserved_books', JSON.stringify(books));
  }, [books]);

  useEffect(() => {
    localStorage.setItem('libreserved_reservations', JSON.stringify(reservations));
  }, [reservations]);

  useEffect(() => {
    localStorage.setItem('libreserved_notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Keep browser URL synchronized as libreservelv
  useEffect(() => {
    try {
      const targetPath = activeView === 'home' ? '/libreservelv' : `/libreservelv/${activeView}`;
      if (window.location.pathname !== targetPath) {
        window.history.replaceState({ view: activeView }, '', targetPath);
      }
    } catch (e) {
      // In sandboxed environments if replaceState is restricted, gracefully fallback
    }
  }, [activeView]);

  const login = (
    email: string,
    role: UserRole,
    password?: string,
    customName?: string,
    _isNewAccount?: boolean
  ): { success: boolean; error?: string } => {
    let trimmed = email.trim().toLowerCase();
    if (!trimmed) {
      return { success: false, error: 'Please enter your email address.' };
    }

    // Auto-append appropriate domain if user entered a username without @
    if (!trimmed.includes('@')) {
      trimmed = role === 'student' ? `${trimmed}@student.laverdad.edu.ph` : `${trimmed}@laverdad.edu.ph`;
    }

    const existingAccount = registeredAccounts[trimmed];

    // Priority: entered password -> previously remembered/saved password -> existing account password -> 'password'
    let userPassword = (password && password.trim()) || '';
    if (!userPassword) {
      try {
        const savedPasswords = JSON.parse(localStorage.getItem('libreserved_remembered_passwords') || '{}');
        if (savedPasswords[trimmed]) {
          userPassword = savedPasswords[trimmed];
        }
      } catch (e) {
        console.error(e);
      }
    }
    if (!userPassword && existingAccount?.password) {
      userPassword = existingAccount.password;
    }
    if (!userPassword) {
      userPassword = 'password';
    }

    // Always remember password in storage so it is never lost
    try {
      const savedPasswords = JSON.parse(localStorage.getItem('libreserved_remembered_passwords') || '{}');
      savedPasswords[trimmed] = userPassword;
      localStorage.setItem('libreserved_remembered_passwords', JSON.stringify(savedPasswords));
      localStorage.setItem('libreserved_last_email', trimmed);
    } catch (e) {
      console.error(e);
    }

    // Role-specific domain validation
    if (role === 'librarian') {
      // Students cannot access librarian portal
      if (trimmed.endsWith('@student.laverdad.edu.ph')) {
        return {
          success: false,
          error: 'Access restricted: Student accounts (@student.laverdad.edu.ph) cannot access the Librarian Circulation Portal.',
        };
      }

      // Check for particular librarian institutional domain: @laverdad.edu.ph
      const isValidLibrarian = trimmed.endsWith('@laverdad.edu.ph');
      if (!isValidLibrarian) {
        return {
          success: false,
          error: 'Librarian Portal requires an @laverdad.edu.ph staff email account.',
        };
      }

      const existingAccount = registeredAccounts[trimmed];

      // Any password grants immediate access to the librarian portal
      if (existingAccount) {
        const updatedLibrarian: User = {
          ...existingAccount,
          role: 'librarian',
          password: userPassword,
        };
        setRegisteredAccounts((prev) => ({ ...prev, [trimmed]: updatedLibrarian }));
        setCurrentUser(updatedLibrarian);
        setActiveView('librarian');
        return { success: true };
      } else {
        // Create new librarian profile and admit immediately with user's chosen password
        const usernamePrefix = trimmed.split('@')[0];
        const formattedName =
          customName?.trim() ||
          usernamePrefix.split('.')[0].charAt(0).toUpperCase() + usernamePrefix.split('.')[0].slice(1) + ' (Staff)';

        const newLibrarian: User = {
          id: `lib-${Date.now()}`,
          name: formattedName,
          email: trimmed,
          role: 'librarian',
          password: userPassword,
          department: 'LVCC Main Library & Circulation Office',
        };

        setRegisteredAccounts((prev) => ({ ...prev, [trimmed]: newLibrarian }));
        setCurrentUser(newLibrarian);
        setActiveView('librarian');
        return { success: true };
      }
    } else {
      // Student login
      // Reject if student portal is accessed with pure librarian staff email
      if (trimmed.endsWith('@laverdad.edu.ph') && !trimmed.endsWith('@student.laverdad.edu.ph')) {
        return {
          success: false,
          error: 'This is a librarian staff email. Please log in through the "Log In as a Librarian" portal.',
        };
      }

      // Check for institutional student domain: @student.laverdad.edu.ph
      const isValidStudent = trimmed.endsWith('@student.laverdad.edu.ph');
      if (!isValidStudent) {
        return {
          success: false,
          error: 'Student Portal requires an @student.laverdad.edu.ph institutional email account.',
        };
      }

      const existingAccount = registeredAccounts[trimmed];

      // Any password grants immediate access to the student portal
      if (existingAccount) {
        const updatedStudent: User = {
          ...existingAccount,
          role: 'student',
          password: userPassword,
        };
        setRegisteredAccounts((prev) => ({ ...prev, [trimmed]: updatedStudent }));
        setCurrentUser(updatedStudent);
        setActiveView('student');
        return { success: true };
      } else {
        // Create new student profile and admit immediately with user's chosen password
        const usernamePrefix = trimmed.split('@')[0];
        const formattedName =
          customName?.trim() ||
          usernamePrefix.split('.')[0].charAt(0).toUpperCase() + usernamePrefix.split('.')[0].slice(1);

        const newStudent: User = {
          id: `stud-${Date.now()}`,
          name: formattedName,
          email: trimmed,
          role: 'student',
          password: userPassword,
          studentNumber: `LVCC-2024-${Math.floor(1000 + Math.random() * 9000)}`,
          department: 'La Verdad Christian College',
        };

        setRegisteredAccounts((prev) => ({ ...prev, [trimmed]: newStudent }));
        setCurrentUser(newStudent);
        setActiveView('student');
        return { success: true };
      }
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setActiveView('home');
  };

  // Student slot calculation
  const reserveBook = (bookId: string): { success: boolean; message: string } => {
    if (!currentUser || currentUser.role !== 'student') {
      return { success: false, message: 'You must be logged in as a student to reserve books.' };
    }

    const targetBook = books.find((b) => b.id === bookId);
    if (!targetBook) {
      return { success: false, message: 'Book not found in library catalog.' };
    }

    // Check active slots used by this student (max 5)
    const studentActiveReservations = reservations.filter(
      (r) => r.studentEmail === currentUser.email && ['pending', 'ready_for_pickup', 'borrowed', 'waitlisted'].includes(r.status)
    );

    if (studentActiveReservations.length >= 5) {
      return {
        success: false,
        message: 'Reservation limit reached: You have already used all 5 available reservation slots.'
      };
    }

    // Check if student already has active reservation for this exact book
    const existing = reservations.find(
      (r) => r.studentEmail === currentUser.email && r.bookId === bookId && ['pending', 'ready_for_pickup', 'borrowed', 'waitlisted'].includes(r.status)
    );
    if (existing) {
      return {
        success: false,
        message: `You already have an active request for "${targetBook.title}" (Status: ${existing.status.replace('_', ' ')}).`
      };
    }

    const today = new Date();
    const pickupDate = new Date(today);
    pickupDate.setDate(today.getDate() + 3);
    const dueDate = new Date(today);
    dueDate.setDate(today.getDate() + 10);

    const formatDate = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    if (targetBook.availableCopies > 0) {
      // Immediate reservation
      const newReservation: Reservation = {
        id: `res-${Date.now()}`,
        bookId: targetBook.id,
        bookTitle: targetBook.title,
        bookAuthor: targetBook.author,
        bookCover: targetBook.coverImage,
        callNumber: targetBook.callNumber,
        studentId: currentUser.id,
        studentName: currentUser.name,
        studentEmail: currentUser.email,
        reservationDate: formatDate(today),
        pickupDeadline: formatDate(pickupDate),
        dueDate: formatDate(dueDate),
        status: 'ready_for_pickup',
        notes: 'Reserved via LibReserved LV student portal. Ready at circulation desk.',
      };

      // Decrement copies
      setBooks((prev) =>
        prev.map((b) => (b.id === bookId ? { ...b, availableCopies: Math.max(0, b.availableCopies - 1) } : b))
      );

      setReservations((prev) => [newReservation, ...prev]);

      // Notification
      const newNotif: LibraryNotification = {
        id: `notif-${Date.now()}`,
        studentEmail: currentUser.email,
        title: 'Book Reserved Successfully!',
        message: `"${targetBook.title}" is ready for pickup at the LVCC library desk before ${formatDate(pickupDate)}.`,
        timestamp: 'Just now',
        read: false,
        type: 'ready_pickup',
        reservationId: newReservation.id,
      };
      setNotifications((prev) => [newNotif, ...prev]);

      return {
        success: true,
        message: `"${targetBook.title}" reserved! Pick it up at the library counter by ${formatDate(pickupDate)}.`
      };
    } else {
      // Join waitlist
      const waitlistCount = reservations.filter((r) => r.bookId === bookId && r.status === 'waitlisted').length;
      const position = waitlistCount + 1;

      const newReservation: Reservation = {
        id: `res-wait-${Date.now()}`,
        bookId: targetBook.id,
        bookTitle: targetBook.title,
        bookAuthor: targetBook.author,
        bookCover: targetBook.coverImage,
        callNumber: targetBook.callNumber,
        studentId: currentUser.id,
        studentName: currentUser.name,
        studentEmail: currentUser.email,
        reservationDate: formatDate(today),
        pickupDeadline: 'When copy is returned',
        dueDate: '7 days upon release',
        status: 'waitlisted',
        waitlistPosition: position,
        notes: `Joined waitlist queue position #${position}`,
      };

      setReservations((prev) => [newReservation, ...prev]);

      const newNotif: LibraryNotification = {
        id: `notif-${Date.now()}`,
        studentEmail: currentUser.email,
        title: 'Joined Book Waitlist',
        message: `You are #${position} in line for "${targetBook.title}". We will notify you once a copy is returned!`,
        timestamp: 'Just now',
        read: false,
        type: 'waitlist',
        reservationId: newReservation.id,
      };
      setNotifications((prev) => [newNotif, ...prev]);

      return {
        success: true,
        message: `Joined waitlist for "${targetBook.title}" (Queue Position: #${position}). We will notify you when available!`
      };
    }
  };

  const cancelReservation = (reservationId: string) => {
    const res = reservations.find((r) => r.id === reservationId);
    if (!res) return;

    // If it was reserved or ready, release book copy
    if (['pending', 'ready_for_pickup'].includes(res.status)) {
      setBooks((prev) =>
        prev.map((b) => (b.id === res.bookId ? { ...b, availableCopies: Math.min(b.totalCopies, b.availableCopies + 1) } : b))
      );
    }

    setReservations((prev) =>
      prev.map((r) => (r.id === reservationId ? { ...r, status: 'cancelled' } : r))
    );
  };

  const updateReservationStatus = (reservationId: string, newStatus: ReservationStatus) => {
    const res = reservations.find((r) => r.id === reservationId);
    if (!res) return;

    const previousStatus = res.status;

    // Handle return
    if (newStatus === 'returned' && previousStatus !== 'returned') {
      // Return book copy
      setBooks((prev) =>
        prev.map((b) => (b.id === res.bookId ? { ...b, availableCopies: Math.min(b.totalCopies, b.availableCopies + 1) } : b))
      );

      // Check if someone is on the waitlist for this book
      const firstWaitlisted = reservations.find((r) => r.bookId === res.bookId && r.status === 'waitlisted');
      if (firstWaitlisted) {
        const today = new Date();
        const pickupDate = new Date(today);
        pickupDate.setDate(today.getDate() + 3);
        const dueDate = new Date(today);
        dueDate.setDate(today.getDate() + 10);
        const formatDate = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

        // Promote waitlisted
        setReservations((prev) =>
          prev.map((r) =>
            r.id === firstWaitlisted.id
              ? {
                  ...r,
                  status: 'ready_for_pickup',
                  pickupDeadline: formatDate(pickupDate),
                  dueDate: formatDate(dueDate),
                  waitlistPosition: undefined,
                  notes: 'Waitlist promoted: copy became available upon return.'
                }
              : r.id === reservationId
              ? { ...r, status: newStatus }
              : r
          )
        );

        // Deduct book back for the promoted student
        setBooks((prev) =>
          prev.map((b) => (b.id === res.bookId ? { ...b, availableCopies: Math.max(0, b.availableCopies - 1) } : b))
        );

        // Notify the promoted student
        setNotifications((prev) => [
          {
            id: `notif-${Date.now()}`,
            studentEmail: firstWaitlisted.studentEmail,
            title: 'Waitlist Update: Book Ready!',
            message: `Good news! "${res.bookTitle}" is now available and reserved for you. Pick up before ${formatDate(pickupDate)}.`,
            timestamp: 'Just now',
            read: false,
            type: 'ready_pickup',
            reservationId: firstWaitlisted.id,
          },
          ...prev,
        ]);
        return;
      }
    }

    setReservations((prev) =>
      prev.map((r) => (r.id === reservationId ? { ...r, status: newStatus } : r))
    );
  };

  const addBook = (newBook: Omit<Book, 'id'>) => {
    const bookWithId: Book = {
      ...newBook,
      id: `b-${Date.now()}`,
      availableCopies: newBook.totalCopies,
    };
    setBooks((prev) => [bookWithId, ...prev]);
  };

  const updateBook = (id: string, updates: Partial<Book>) => {
    setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, ...updates } : b)));
  };

  const deleteBook = (id: string) => {
    setBooks((prev) => prev.filter((b) => b.id !== id));
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const clearAllNotifications = () => {
    if (!currentUser) return;
    setNotifications((prev) => prev.filter((n) => n.studentEmail !== currentUser.email));
  };

  const exportCirculationPDF = (reportType: ExportReportType = 'both') => {
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const timestampSlug = new Date().toISOString().split('T')[0];
      const generatedAt = new Date().toLocaleString();

      const totalRes = reservations.length;
      const awaitingPickup = reservations.filter((r) => r.status === 'ready_for_pickup').length;
      const currentlyBorrowed = reservations.filter((r) => r.status === 'borrowed').length;
      const returned = reservations.filter((r) => r.status === 'returned').length;
      const totalInventory = books.reduce((acc, b) => acc + b.totalCopies, 0);
      const availableInventory = books.reduce((acc, b) => acc + b.availableCopies, 0);

      // Section 1: ACTIVE RESERVATIONS & BORROWERS REPORT
      if (reportType === 'borrowers' || reportType === 'both') {
        // Header Banner
        doc.setFillColor(22, 50, 92); // #16325C
        doc.rect(0, 0, 210, 32, 'F');

        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(17);
        doc.text(
          reportType === 'both'
            ? 'LibReserved LV - Comprehensive Circulation & Inventory Report'
            : 'LibReserved LV - Active Reservations & Borrowers Report',
          14,
          15
        );

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9.5);
        doc.setTextColor(212, 160, 23); // Gold #D4A017
        doc.text('LA VERDAD CHRISTIAN COLLEGE - MAIN CAMPUS LIBRARY SYSTEM', 14, 22);

        doc.setTextColor(220, 225, 235);
        doc.setFontSize(8.5);
        doc.text(`Generated: ${generatedAt} · Tagline: "Reserved, Borrow, and Learned."`, 14, 28);

        // Summary KPI Box
        let yPos = 40;
        doc.setFillColor(248, 250, 252);
        doc.setDrawColor(226, 232, 240);
        doc.roundedRect(14, yPos, 182, 20, 2, 2, 'FD');

        doc.setTextColor(22, 50, 92);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9.5);
        doc.text('CIRCULATION METRICS OVERVIEW', 18, yPos + 6.5);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(51, 65, 85);
        doc.text(`Total Reservations: ${totalRes}`, 18, yPos + 14);
        doc.text(`Awaiting Pickup: ${awaitingPickup}`, 65, yPos + 14);
        doc.text(`Currently Borrowed: ${currentlyBorrowed}`, 115, yPos + 14);
        doc.text(`Returned: ${returned}`, 165, yPos + 14);

        yPos = 68;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(22, 50, 92);
        doc.text(`Active Reservations & Borrowers List (${reservations.length} total records)`, 14, yPos);

        yPos += 5;
        // Table Header
        doc.setFillColor(22, 50, 92);
        doc.rect(14, yPos, 182, 8, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.text('STUDENT', 16, yPos + 5.5);
        doc.text('BOOK TITLE & CALL NO.', 60, yPos + 5.5);
        doc.text('RESERVED', 125, yPos + 5.5);
        doc.text('DUE / PICKUP', 150, yPos + 5.5);
        doc.text('STATUS', 178, yPos + 5.5);

        yPos += 8;

        reservations.forEach((r, idx) => {
          if (yPos > 265) {
            doc.addPage();
            yPos = 20;
            doc.setFillColor(22, 50, 92);
            doc.rect(14, yPos, 182, 8, 'F');
            doc.setTextColor(255, 255, 255);
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(8);
            doc.text('STUDENT', 16, yPos + 5.5);
            doc.text('BOOK TITLE & CALL NO.', 60, yPos + 5.5);
            doc.text('RESERVED', 125, yPos + 5.5);
            doc.text('DUE / PICKUP', 150, yPos + 5.5);
            doc.text('STATUS', 178, yPos + 5.5);
            yPos += 8;
          }

          const isEven = idx % 2 === 0;
          doc.setFillColor(isEven ? 255 : 249, isEven ? 255 : 250, isEven ? 255 : 251);
          doc.rect(14, yPos, 182, 9, 'F');
          doc.setDrawColor(241, 245, 249);
          doc.line(14, yPos + 9, 196, yPos + 9);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(7.5);
          doc.setTextColor(30, 41, 59);

          // Student name and email
          doc.text(r.studentName.substring(0, 22), 16, yPos + 4);
          doc.setTextColor(100, 116, 139);
          doc.text(r.studentEmail.substring(0, 26), 16, yPos + 7.5);

          // Book title & Call number
          doc.setTextColor(30, 41, 59);
          doc.text(r.bookTitle.substring(0, 32), 60, yPos + 4);
          doc.setTextColor(100, 116, 139);
          doc.text(r.callNumber.substring(0, 28), 60, yPos + 7.5);

          doc.setTextColor(51, 65, 85);
          doc.text(r.reservationDate, 125, yPos + 5.5);
          doc.text(r.pickupDeadline || r.dueDate, 150, yPos + 5.5);

          // Status badge
          const statusClean = r.status === 'ready_for_pickup' ? 'READY' : r.status.replace(/_/g, ' ').toUpperCase();
          if (r.status === 'ready_for_pickup') {
            doc.setTextColor(180, 100, 0);
          } else if (r.status === 'borrowed') {
            doc.setTextColor(20, 100, 200);
          } else if (r.status === 'returned') {
            doc.setTextColor(30, 150, 70);
          } else {
            doc.setTextColor(80, 80, 80);
          }
          doc.setFont('helvetica', 'bold');
          doc.text(statusClean, 178, yPos + 5.5);

          yPos += 9;
        });

        // Footer for Borrowers section
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(7);
        doc.setTextColor(148, 163, 184);
        doc.text(
          'La Verdad Christian College Library · Official Borrowers Ledger · Books Free for Student Borrowing',
          14,
          287
        );
      }

      // Section 2: LIBRARY INVENTORY SUMMARY REPORT
      if (reportType === 'inventory' || reportType === 'both') {
        let yPos = 20;

        if (reportType === 'both') {
          doc.addPage();
        } else {
          // Dedicated Inventory Header Banner
          doc.setFillColor(22, 50, 92);
          doc.rect(0, 0, 210, 32, 'F');

          doc.setTextColor(255, 255, 255);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(17);
          doc.text('LibReserved LV - Library Inventory Summary Report', 14, 15);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(9.5);
          doc.setTextColor(212, 160, 23);
          doc.text('LA VERDAD CHRISTIAN COLLEGE - MAIN CAMPUS LIBRARY SYSTEM', 14, 22);

          doc.setTextColor(220, 225, 235);
          doc.setFontSize(8.5);
          doc.text(`Generated: ${generatedAt} · Tagline: "Reserved, Borrow, and Learned."`, 14, 28);

          yPos = 40;
        }

        // Inventory KPI card
        doc.setFillColor(248, 250, 252);
        doc.setDrawColor(226, 232, 240);
        doc.roundedRect(14, yPos, 182, 20, 2, 2, 'FD');

        doc.setTextColor(22, 50, 92);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9.5);
        doc.text('COLLECTION & SHELF HOLDINGS SUMMARY', 18, yPos + 6.5);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(51, 65, 85);
        doc.text(`Total Catalog Titles: ${books.length}`, 18, yPos + 14);
        doc.text(`Total Physical Copies: ${totalInventory}`, 70, yPos + 14);
        doc.text(`Available on Shelf: ${availableInventory}`, 120, yPos + 14);
        doc.text(`Checked Out: ${totalInventory - availableInventory}`, 162, yPos + 14);

        yPos += 28;

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(22, 50, 92);
        doc.text(`Library Shelf Inventory Catalog (${books.length} titles · ${availableInventory}/${totalInventory} in library)`, 14, yPos);

        yPos += 5;
        doc.setFillColor(22, 50, 92);
        doc.rect(14, yPos, 182, 8, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(7.5);
        doc.setFont('helvetica', 'bold');
        doc.text('TITLE & CALL NO.', 16, yPos + 5.5);
        doc.text('AUTHOR', 80, yPos + 5.5);
        doc.text('CATEGORY & SHELF LOCATION', 125, yPos + 5.5);
        doc.text('COPIES IN', 178, yPos + 5.5);

        yPos += 8;

        books.forEach((b, idx) => {
          if (yPos > 265) {
            doc.addPage();
            yPos = 20;
            doc.setFillColor(22, 50, 92);
            doc.rect(14, yPos, 182, 8, 'F');
            doc.setTextColor(255, 255, 255);
            doc.setFontSize(7.5);
            doc.setFont('helvetica', 'bold');
            doc.text('TITLE & CALL NO.', 16, yPos + 5.5);
            doc.text('AUTHOR', 80, yPos + 5.5);
            doc.text('CATEGORY & SHELF LOCATION', 125, yPos + 5.5);
            doc.text('COPIES IN', 178, yPos + 5.5);
            yPos += 8;
          }

          const isEven = idx % 2 === 0;
          doc.setFillColor(isEven ? 255 : 249, isEven ? 255 : 250, isEven ? 255 : 251);
          doc.rect(14, yPos, 182, 9, 'F');
          doc.setDrawColor(241, 245, 249);
          doc.line(14, yPos + 9, 196, yPos + 9);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(7.5);
          doc.setTextColor(30, 41, 59);
          doc.text(b.title.substring(0, 34), 16, yPos + 4);

          doc.setTextColor(100, 116, 139);
          doc.text(b.callNumber.substring(0, 30), 16, yPos + 7.5);
          doc.text(b.author.substring(0, 26), 80, yPos + 5.5);

          doc.setTextColor(51, 65, 85);
          doc.text(`${b.category.split('&')[0]} · ${b.shelfLocation.substring(0, 24)}`, 125, yPos + 5.5);

          doc.setTextColor(22, 50, 92);
          doc.setFont('helvetica', 'bold');
          doc.text(`${b.availableCopies}/${b.totalCopies}`, 180, yPos + 5.5);

          yPos += 9;
        });

        // Footer for Inventory section
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(7);
        doc.setTextColor(148, 163, 184);
        doc.text(
          'La Verdad Christian College Library · Official Shelf Inventory Document · LibReserved LV',
          14,
          287
        );
      }

      let filename = `LibReserved_LV_Comprehensive_Report_${timestampSlug}.pdf`;
      if (reportType === 'borrowers') {
        filename = `LibReserved_LV_Borrowers_Report_${timestampSlug}.pdf`;
      } else if (reportType === 'inventory') {
        filename = `LibReserved_LV_Inventory_Report_${timestampSlug}.pdf`;
      }

      doc.save(filename);
    } catch (err) {
      console.error('Failed to export PDF:', err);
      window.print();
    }
  };

  return (
    <LibraryContext.Provider
      value={{
        currentUser,
        books,
        reservations,
        notifications,
        login,
        logout,
        reserveBook,
        cancelReservation,
        updateReservationStatus,
        addBook,
        updateBook,
        deleteBook,
        markNotificationAsRead,
        clearAllNotifications,
        exportCirculationPDF,
        activeView,
        setActiveView,
      }}
    >
      {children}
    </LibraryContext.Provider>
  );
};

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  if (!context) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
};
