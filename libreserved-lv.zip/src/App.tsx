import React, { useState } from 'react';
import { LibraryProvider, useLibrary } from './context/LibraryContext';
import { Header } from './components/Header';
import { Homepage } from './components/Homepage';
import { StudentPortal } from './components/StudentPortal';
import { LibrarianPortal } from './components/LibrarianPortal';
import { AuthModal } from './components/AuthModal';
import { BookDetailModal } from './components/BookDetailModal';
import { Footer } from './components/Footer';
import { Book, UserRole } from './types/library';
import { ShieldAlert } from 'lucide-react';

const MainApp: React.FC = () => {
  const { currentUser, activeView, setActiveView, login } = useLibrary();

  // Auth modal state
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authInitialRole, setAuthInitialRole] = useState<UserRole>('student');

  // Book modal state
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  // Tab states for Student Portal and Librarian Portal
  const [studentTab, setStudentTab] = useState<'find-books' | 'my-reservations' | 'overview' | 'notifications'>('find-books');
  const [librarianTab, setLibrarianTab] = useState<'overview' | 'borrowers' | 'inventory' | 'add-book'>('overview');

  const handleOpenAuth = (role: UserRole = 'student') => {
    setAuthInitialRole(role);
    setIsAuthOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F5] text-slate-800">
      {/* Main Navigation Header */}
      <Header
        onOpenAuth={handleOpenAuth}
        studentTab={studentTab}
        setStudentTab={setStudentTab}
        librarianTab={librarianTab}
        setLibrarianTab={setLibrarianTab}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Homepage View */}
        {activeView === 'home' && (
          <Homepage
            onOpenAuth={handleOpenAuth}
            onSelectBook={(book) => setSelectedBook(book)}
          />
        )}

        {/* Student Portal View */}
        {activeView === 'student' && (
          <>
            {currentUser?.role === 'student' ? (
              <StudentPortal
                currentTab={studentTab}
                setTab={setStudentTab}
                onSelectBook={(book) => setSelectedBook(book)}
              />
            ) : (
              <div className="max-w-xl mx-auto my-16 p-8 bg-white rounded-2xl border border-slate-200 text-center space-y-4">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto text-amber-700">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <h2 className="text-lg font-bold text-slate-900">Student Sign In Required</h2>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Please log in with your @student.laverdad.edu.ph email account to view your book reservations, 5-slot allocation status, and due date reminders.
                </p>
                <button
                  onClick={() => handleOpenAuth('student')}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#16325C] rounded-lg shadow-sm"
                >
                  Log In as a Student
                </button>
              </div>
            )}
          </>
        )}

        {/* Librarian Portal View */}
        {activeView === 'librarian' && (
          <>
            {currentUser?.role === 'librarian' ? (
              <LibrarianPortal
                currentTab={librarianTab}
                setTab={setLibrarianTab}
                onSelectBook={(book) => setSelectedBook(book)}
              />
            ) : (
              <div className="max-w-xl mx-auto my-16 p-8 bg-white rounded-2xl border border-red-200 text-center space-y-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto text-red-700">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <h2 className="text-lg font-bold text-slate-900">Restricted Librarian Access</h2>
                <p className="text-xs text-slate-600 leading-relaxed">
                  This portal is reserved strictly for authorized La Verdad Christian College library staff (@laverdad.edu.ph). Students cannot access circulation administrative tools.
                </p>
                <div className="flex justify-center gap-3">
                  <button
                    onClick={() => setActiveView('home')}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                  >
                    Return to Homepage
                  </button>
                  <button
                    onClick={() => handleOpenAuth('librarian')}
                    className="px-4.5 py-2 text-xs font-semibold text-white bg-[#16325C] hover:bg-[#1a3d6f] rounded-lg shadow-sm"
                  >
                    Staff Sign In
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Book Details Modal */}
      <BookDetailModal
        book={selectedBook}
        onClose={() => setSelectedBook(null)}
        onOpenAuth={handleOpenAuth}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        initialRole={authInitialRole}
      />

      {/* Footer */}
      <Footer onOpenAuth={handleOpenAuth} />
    </div>
  );
};

export default function App() {
  return (
    <LibraryProvider>
      <MainApp />
    </LibraryProvider>
  );
}
